"""
animation_engine.py — Timed Animation Driver
===============================================
Drives the ``VisualizationPanel`` animations from simulation events.

Runs on the Tkinter main-thread ``after()`` loop — no separate threads
needed for the GUI updates.
"""

from __future__ import annotations

import time
import tkinter as tk
from typing import Optional, List, Dict, Any, Callable

from ipc_debugger_tool.visualization.visualization_panel import VisualizationPanel


class AnimationEngine:
    """
    Consumes events and translates them into canvas animations.

    Usage
    -----
    1. Create an instance with a ``VisualizationPanel``.
    2. Call ``schedule(event_dict)`` whenever an IPC event occurs.
    3. The engine batches and replays them on the next Tkinter frame.
    """

    def __init__(self, panel: VisualizationPanel,
                 packet_duration_ms: int = 800) -> None:
        self.panel = panel
        self.packet_duration_ms = packet_duration_ms
        self._queue: List[Dict[str, Any]] = []
        self._running = False
        self._after_id: Optional[str] = None

    # -- event intake --------------------------------------------------------

    def schedule(self, event: Dict[str, Any]) -> None:
        """Queue an event for the next animation frame."""
        self._queue.append(event)

    # -- animation loop ------------------------------------------------------

    def start(self, root: tk.Tk, fps: int = 30) -> None:
        """Begin the animation loop on the Tkinter event loop."""
        self._running = True
        interval = max(1, 1000 // fps)
        self._tick(root, interval)

    def stop(self) -> None:
        self._running = False

    def _tick(self, root: tk.Tk, interval: int) -> None:
        if not self._running:
            return
        self._process_queue()
        self._after_id = root.after(interval, self._tick, root, interval)

    def _process_queue(self) -> None:
        """Drain the event queue and trigger animations."""
        events = list(self._queue)
        self._queue.clear()

        for event in events:
            etype = event.get("type", "")

            # --- data transfer animations ---
            if etype in ("pipe_send", "queue_enqueue", "shm_write"):
                channel = event.get("channel")
                if channel:
                    self.panel.animate_packet(
                        channel, self.packet_duration_ms
                    )

            # --- node state changes ---
            if etype == "process_started":
                pid = event.get("pid")
                if pid is not None:
                    self.panel.update_node_state(pid, "running")
            if etype == "process_stopped":
                pid = event.get("pid")
                if pid is not None:
                    self.panel.update_node_state(pid, "terminated")

            # --- deadlock alert ---
            if etype == "deadlock_detected":
                cycle = event.get("cycle", [])
                self.panel.show_deadlock_alert(cycle, [])

            # --- lock contention (waiting state) ---
            if etype == "shm_lock_acquire" and event.get("contended"):
                pid = event.get("pid")
                if pid is not None:
                    self.panel.update_node_state(pid, "waiting")
            if etype == "shm_lock_release":
                pid = event.get("pid")
                if pid is not None:
                    self.panel.update_node_state(pid, "running")
