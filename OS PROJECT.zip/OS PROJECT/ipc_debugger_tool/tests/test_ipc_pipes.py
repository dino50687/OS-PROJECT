"""
test_ipc_pipes.py — Unit tests for PipeCommunicator
"""

import sys
import os
import time
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.ipc.ipc_pipes import PipeCommunicator


class TestPipeCommunicator:

    def test_send_recv_basic(self):
        """Basic send/recv through a duplex pipe."""
        events = []
        pc = PipeCommunicator(duplex=True, on_event=lambda e: events.append(e))
        pc.send(pc.conn_a, "hello", sender_pid=1, receiver_pid=2)
        result = pc.recv(pc.conn_b, sender_pid=1, receiver_pid=2, timeout=2.0)
        assert result == "hello"
        pc.close()

    def test_stats_tracking(self):
        """Stats should count messages and track latency."""
        pc = PipeCommunicator(duplex=True)
        for i in range(5):
            pc.send(pc.conn_a, i, sender_pid=1, receiver_pid=2)
        for i in range(5):
            pc.recv(pc.conn_b, timeout=2.0)
        stats = pc.get_stats()
        assert stats["messages_sent"] == 5
        assert stats["messages_received"] == 5
        assert stats["avg_latency"] >= 0
        pc.close()

    def test_recv_timeout(self):
        """recv with timeout on empty pipe should return None."""
        pc = PipeCommunicator(duplex=True)
        result = pc.recv(pc.conn_b, timeout=0.1)
        assert result is None
        pc.close()

    def test_event_callback_fires(self):
        """Events should be emitted on send and recv."""
        events = []
        pc = PipeCommunicator(on_event=lambda e: events.append(e))
        pc.send(pc.conn_a, "x", sender_pid=10, receiver_pid=20)
        pc.recv(pc.conn_b, timeout=1.0)
        pc.close()
        types = [e["type"] for e in events]
        assert "pipe_send" in types
        assert "pipe_recv" in types
        assert "pipe_closed" in types

    def test_large_payload(self):
        """Pipes should handle reasonably large pickled objects."""
        import threading
        pc = PipeCommunicator()
        big_data = list(range(10000))
        result_holder = [None]

        def receiver():
            result_holder[0] = pc.recv(pc.conn_b, timeout=10.0)

        t = threading.Thread(target=receiver)
        t.start()
        pc.send(pc.conn_a, big_data)
        t.join(timeout=15.0)
        assert result_holder[0] == big_data
        pc.close()
