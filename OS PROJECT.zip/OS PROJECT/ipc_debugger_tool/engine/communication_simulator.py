"""
communication_simulator.py — IPC Channel Orchestrator
=======================================================
Sets up IPC channels (pipes, message queues, shared memory) between
simulated processes and drives data-transfer scenarios that the
analyzers and visualization can observe.
"""

from __future__ import annotations

import time
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Any, Tuple

from ipc_debugger_tool.ipc.ipc_pipes import PipeCommunicator
from ipc_debugger_tool.ipc.ipc_message_queue import MessageQueueCommunicator
from ipc_debugger_tool.ipc.ipc_shared_memory import SharedMemoryCommunicator


@dataclass
class Channel:
    """Metadata for one IPC channel."""
    name: str
    channel_type: str   # "pipe", "queue", "shm"
    endpoint_a: int     # PID
    endpoint_b: int     # PID
    communicator: Any = field(repr=False, default=None)
    created_at: float = field(default_factory=time.time)


class CommunicationSimulator:
    """
    Creates and manages IPC channels between simulated processes.

    Parameters
    ----------
    on_event : callable, optional
        Forwarded to every communicator and also used for own events.
    """

    def __init__(self, on_event: Optional[Callable] = None):
        self._channels: Dict[str, Channel] = {}
        self._on_event = on_event
        self._shm_counter = 0

    def _emit(self, event: dict) -> None:
        if self._on_event:
            try:
                self._on_event(event)
            except Exception:
                pass

    # -- channel creation ----------------------------------------------------

    def create_pipe(self, name: str,
                    pid_a: int, pid_b: int,
                    duplex: bool = True) -> Channel:
        comm = PipeCommunicator(duplex=duplex, on_event=self._on_event)
        ch = Channel(name=name, channel_type="pipe",
                     endpoint_a=pid_a, endpoint_b=pid_b,
                     communicator=comm)
        self._channels[name] = ch
        self._emit({
            "type": "channel_created",
            "channel": name,
            "channel_type": "pipe",
            "pid_a": pid_a,
            "pid_b": pid_b,
            "time": time.time(),
        })
        return ch

    def create_queue(self, name: str,
                     pid_a: int, pid_b: int,
                     maxsize: int = 0) -> Channel:
        comm = MessageQueueCommunicator(maxsize=maxsize,
                                        on_event=self._on_event)
        ch = Channel(name=name, channel_type="queue",
                     endpoint_a=pid_a, endpoint_b=pid_b,
                     communicator=comm)
        self._channels[name] = ch
        self._emit({
            "type": "channel_created",
            "channel": name,
            "channel_type": "queue",
            "pid_a": pid_a,
            "pid_b": pid_b,
            "time": time.time(),
        })
        return ch

    def create_shared_memory(self, name: str,
                             pid_a: int, pid_b: int,
                             size: int = 1024) -> Channel:
        self._shm_counter += 1
        shm_name = f"ipc_dbg_{self._shm_counter}"
        comm = SharedMemoryCommunicator(name=shm_name, size=size,
                                        on_event=self._on_event)
        ch = Channel(name=name, channel_type="shm",
                     endpoint_a=pid_a, endpoint_b=pid_b,
                     communicator=comm)
        self._channels[name] = ch
        self._emit({
            "type": "channel_created",
            "channel": name,
            "channel_type": "shm",
            "pid_a": pid_a,
            "pid_b": pid_b,
            "time": time.time(),
        })
        return ch

    # -- data transfer helpers -----------------------------------------------

    def send_via_pipe(self, channel_name: str,
                      payload: Any, direction: str = "a_to_b") -> None:
        """Send *payload* through a pipe channel."""
        ch = self._channels[channel_name]
        comm: PipeCommunicator = ch.communicator
        if direction == "a_to_b":
            comm.send(comm.conn_a, payload,
                      sender_pid=ch.endpoint_a,
                      receiver_pid=ch.endpoint_b)
        else:
            comm.send(comm.conn_b, payload,
                      sender_pid=ch.endpoint_b,
                      receiver_pid=ch.endpoint_a)

    def recv_via_pipe(self, channel_name: str,
                      direction: str = "a_to_b",
                      timeout: float = 2.0) -> Any:
        ch = self._channels[channel_name]
        comm: PipeCommunicator = ch.communicator
        if direction == "a_to_b":
            return comm.recv(comm.conn_b,
                             sender_pid=ch.endpoint_a,
                             receiver_pid=ch.endpoint_b,
                             timeout=timeout)
        else:
            return comm.recv(comm.conn_a,
                             sender_pid=ch.endpoint_b,
                             receiver_pid=ch.endpoint_a,
                             timeout=timeout)

    def enqueue(self, channel_name: str, payload: Any,
                sender_pid: int = 0) -> None:
        ch = self._channels[channel_name]
        comm: MessageQueueCommunicator = ch.communicator
        comm.enqueue(payload, sender_pid=sender_pid or ch.endpoint_a)

    def dequeue(self, channel_name: str,
                receiver_pid: int = 0,
                timeout: float = 2.0) -> Any:
        ch = self._channels[channel_name]
        comm: MessageQueueCommunicator = ch.communicator
        return comm.dequeue(receiver_pid=receiver_pid or ch.endpoint_b,
                            timeout=timeout)

    def shm_write(self, channel_name: str, data: bytes,
                  pid: int = 0, offset: int = 0) -> None:
        ch = self._channels[channel_name]
        comm: SharedMemoryCommunicator = ch.communicator
        comm.acquire_lock(pid=pid or ch.endpoint_a)
        try:
            comm.write_bytes(data, offset=offset, pid=pid or ch.endpoint_a)
        finally:
            comm.release_lock(pid=pid or ch.endpoint_a)

    def shm_read(self, channel_name: str, length: int,
                 pid: int = 0, offset: int = 0) -> bytes:
        ch = self._channels[channel_name]
        comm: SharedMemoryCommunicator = ch.communicator
        comm.acquire_lock(pid=pid or ch.endpoint_b)
        try:
            return comm.read_bytes(length, offset=offset,
                                   pid=pid or ch.endpoint_b)
        finally:
            comm.release_lock(pid=pid or ch.endpoint_b)

    # -- queries -------------------------------------------------------------

    def get_channel(self, name: str) -> Optional[Channel]:
        return self._channels.get(name)

    def get_all_channels(self) -> List[Channel]:
        return list(self._channels.values())

    def get_stats(self, name: str) -> dict:
        ch = self._channels.get(name)
        if ch is None:
            return {}
        return ch.communicator.get_stats()

    def get_all_stats(self) -> Dict[str, dict]:
        result = {}
        for name, ch in self._channels.items():
            result[name] = {
                "type": ch.channel_type,
                "stats": ch.communicator.get_stats(),
            }
        return result

    # -- cleanup -------------------------------------------------------------

    def close_channel(self, name: str) -> None:
        ch = self._channels.pop(name, None)
        if ch and ch.communicator:
            ch.communicator.close()

    def close_all(self) -> None:
        for name in list(self._channels):
            self.close_channel(name)
