#!/usr/bin/env python3
"""
main.py — IPC Debugger Tool Entry Point
==========================================
Launch the full GUI application.

Usage
-----
    python main.py          # launch GUI
    python main.py --demo   # launch GUI with demo processes pre-loaded
"""

from __future__ import annotations

import sys
import os

# Ensure the project root is on the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# Also add parent so "ipc_debugger_tool" package is importable
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main() -> None:
    from ipc_debugger_tool.gui.main_window import MainWindow

    app = MainWindow()

    # If --demo flag, pre-populate some processes and channels
    if "--demo" in sys.argv:
        _load_demo(app)

    app.run()


def _load_demo(app) -> None:
    """Pre-create 3 processes and 2 channels for quick demonstration."""
    from ipc_debugger_tool.engine.process_simulator import ProcessSimulator

    for name in ["Producer", "Consumer", "Monitor"]:
        app.proc_name_var.set(name)
        app._add_process()

    procs = app.process_sim.get_all_processes()
    if len(procs) >= 2:
        # Pipe: Producer → Consumer
        app.ipc_type_var.set("Pipe")
        app.from_pid_var.set(f"{procs[0].pid} - {procs[0].name}")
        app.to_pid_var.set(f"{procs[1].pid} - {procs[1].name}")
        app._connect_channel()

    if len(procs) >= 3:
        # Queue: Consumer → Monitor
        app.ipc_type_var.set("Message Queue")
        app.from_pid_var.set(f"{procs[1].pid} - {procs[1].name}")
        app.to_pid_var.set(f"{procs[2].pid} - {procs[2].name}")
        app._connect_channel()

    app.logger.info("Demo scenario loaded: Producer → Consumer → Monitor")


if __name__ == "__main__":
    main()
