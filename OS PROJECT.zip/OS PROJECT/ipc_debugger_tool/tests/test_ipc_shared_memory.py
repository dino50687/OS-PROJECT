"""
test_ipc_shared_memory.py — Unit tests for SharedMemoryCommunicator
"""

import sys
import os
import time
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.ipc.ipc_shared_memory import SharedMemoryCommunicator


class TestSharedMemoryCommunicator:

    def _make(self, name=None):
        import random, string
        if name is None:
            name = "test_" + "".join(random.choices(string.ascii_lowercase, k=8))
        return SharedMemoryCommunicator(name=name, size=256)

    def test_write_read(self):
        shm = self._make()
        shm.acquire_lock(pid=1)
        shm.write_bytes(b"HELLO", offset=0, pid=1)
        shm.release_lock(pid=1)

        shm.acquire_lock(pid=2)
        data = shm.read_bytes(5, offset=0, pid=2)
        shm.release_lock(pid=2)

        assert data == b"HELLO"
        shm.close()

    def test_counter(self):
        shm = self._make()
        for _ in range(10):
            shm.increment_counter(pid=1)
        assert shm.get_counter() == 10
        shm.close()

    def test_stats(self):
        shm = self._make()
        shm.acquire_lock()
        shm.write_bytes(b"AB", pid=1)
        shm.release_lock()
        stats = shm.get_stats()
        assert stats["writes"] == 1
        assert stats["bytes_written"] == 2
        assert stats["lock_acquisitions"] == 1
        shm.close()

    def test_bounds_check(self):
        shm = self._make()
        with pytest.raises(ValueError):
            shm.write_bytes(b"X" * 300, pid=1)  # exceeds 256
        shm.close()

    def test_events(self):
        events = []
        import random, string
        name = "test_" + "".join(random.choices(string.ascii_lowercase, k=8))
        shm = SharedMemoryCommunicator(name=name, size=128,
                                        on_event=lambda e: events.append(e))
        shm.acquire_lock(pid=5)
        shm.write_bytes(b"X", pid=5)
        shm.release_lock(pid=5)
        shm.close()
        types = [e["type"] for e in events]
        assert "shm_lock_acquire" in types
        assert "shm_write" in types
        assert "shm_lock_release" in types
