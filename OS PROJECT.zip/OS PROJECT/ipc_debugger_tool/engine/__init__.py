"""
Engine Package
===============
Simulation engines that create and orchestrate virtual processes and
IPC channels:
  - ProcessSimulator — spawns / manages simulated processes
  - CommunicationSimulator — sets up IPC channels between them
"""

from .process_simulator import ProcessSimulator
from .communication_simulator import CommunicationSimulator

__all__ = [
    "ProcessSimulator",
    "CommunicationSimulator",
]
