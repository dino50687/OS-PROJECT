"""
ipc_shared_memory.py — Shared-Memory-based IPC Communicator
=============================================================
Wraps ``multiprocessing.shared_memory`` (Python 3.8+) and
``multiprocessing.Value`` / ``multiprocessing.Array`` with instrumentation.

**Shared Memory** maps the same physical pages into the virtual address
spaces of multiple processes, giving the fastest possible data sharing
(no kernel copy) — but requiring explicit synchronization.

Practical applications:
    - High-throughput numerical pipelines (image processing, ML inference)
    - Shared state between cooperating servers
    - Memory-mapped databases / caches

Benefits:
    - Zero-copy data sharing — fastest IPC mechanism
    - Arbitrary data layout (struct-like access)

Constraints:
    - Requires explicit locking (mutex / semaphore) → race conditions
    - Fixed size; resizing requires recreation
    - Platform-specific naming semantics

Common coding errors:
    - Forgetting to acquire the lock → data corruption / race condition
    - Double-release of semaphore
    - Not unlinking shared memory → resource leak
    - Reader starvation under heavy write contention
"""

from __future__ import annotations

import time
import ctypes
import multiprocessing
from multiprocessing import shared_memory, Value, Lock
from dataclasses import dataclass, field
from typing import Any, Optional, Callable


@dataclass
class SharedMemoryStats:
    writes: int = 0
    reads: int = 0
    lock_acquisitions: int = 0
    lock_contentions: int = 0        # lock was not immediately available
    total_lock_wait: float = 0.0
    max_lock_wait: float = 0.0
    bytes_written: int = 0

    @property
    def avg_lock_wait(self) -> float:
        if self.lock_acquisitions == 0:
            return 0.0
        return self.total_lock_wait / self.lock_acquisitions


class SharedMemoryCommunicator:
    """
    Instrumented shared-memory region guarded by a ``multiprocessing.Lock``.

    The region is backed by ``multiprocessing.Value`` (for a simple integer
    counter) **and** a raw ``shared_memory.SharedMemory`` block for
    arbitrary bytes.

    Parameters
    ----------
    name : str
        Logical name shown in logs / visualization.
    size : int
        Size of the raw byte region (default 1024).
    on_event : callable, optional
        Callback for every read / write / lock event.
    """

    def __init__(self, name: str = "shm_region",
                 size: int = 1024,
                 on_event: Optional[Callable] = None):
        self.name = name
        self.size = size
        self._on_event = on_event
        self.stats = SharedMemoryStats()

        # A shared integer counter (example shared state)
        self.shared_counter = Value(ctypes.c_int, 0)

        # A raw byte region
        try:
            self.shm = shared_memory.SharedMemory(
                name=name, create=True, size=size
            )
        except FileExistsError:
            # Attach to an existing block
            self.shm = shared_memory.SharedMemory(
                name=name, create=False, size=size
            )
        self._lock = Lock()
        self._closed = False

    def _emit(self, event: dict) -> None:
        if self._on_event:
            try:
                self._on_event(event)
            except Exception:
                pass

    # -- lock helpers --------------------------------------------------------

    def acquire_lock(self, timeout: Optional[float] = None,
                     pid: int = 0) -> bool:
        """Try to acquire the internal lock.  Returns True on success."""
        t0 = time.time()
        if timeout is not None:
            acquired = self._lock.acquire(timeout=timeout)
        else:
            acquired = self._lock.acquire()

        wait_time = time.time() - t0
        if acquired:
            self.stats.lock_acquisitions += 1
            self.stats.total_lock_wait += wait_time
            self.stats.max_lock_wait = max(self.stats.max_lock_wait, wait_time)
            if wait_time > 0.001:
                self.stats.lock_contentions += 1
            self._emit({
                "type": "shm_lock_acquire",
                "pid": pid,
                "wait_time": wait_time,
                "contended": wait_time > 0.001,
                "time": time.time(),
            })
        else:
            self.stats.lock_contentions += 1
            self._emit({
                "type": "shm_lock_timeout",
                "pid": pid,
                "time": time.time(),
            })
        return acquired

    def release_lock(self, pid: int = 0) -> None:
        self._lock.release()
        self._emit({
            "type": "shm_lock_release",
            "pid": pid,
            "time": time.time(),
        })

    # -- read / write --------------------------------------------------------

    def write_bytes(self, data: bytes, offset: int = 0,
                    pid: int = 0) -> None:
        """Write *data* into the shared region at *offset*."""
        if offset + len(data) > self.size:
            raise ValueError("Write exceeds shared memory bounds")
        buf = self.shm.buf
        assert buf is not None, "Shared memory buffer is closed"
        buf[offset:offset + len(data)] = data
        self.stats.writes += 1
        self.stats.bytes_written += len(data)
        self._emit({
            "type": "shm_write",
            "pid": pid,
            "offset": offset,
            "length": len(data),
            "time": time.time(),
        })

    def read_bytes(self, length: int, offset: int = 0,
                   pid: int = 0) -> bytes:
        """Read *length* bytes from the shared region at *offset*."""
        buf = self.shm.buf
        assert buf is not None, "Shared memory buffer is closed"
        data = bytes(buf[offset:offset + length])
        self.stats.reads += 1
        self._emit({
            "type": "shm_read",
            "pid": pid,
            "offset": offset,
            "length": length,
            "time": time.time(),
        })
        return data

    def increment_counter(self, pid: int = 0) -> int:
        """Atomically increment the shared counter and return new value."""
        with self.shared_counter.get_lock():
            self.shared_counter.value += 1
            val = self.shared_counter.value
        self._emit({
            "type": "shm_counter_inc",
            "pid": pid,
            "value": val,
            "time": time.time(),
        })
        return val

    def get_counter(self) -> int:
        return self.shared_counter.value

    # -- lifecycle -----------------------------------------------------------

    def close(self) -> None:
        if not self._closed:
            self.shm.close()
            try:
                self.shm.unlink()
            except FileNotFoundError:
                pass
            self._closed = True
            self._emit({"type": "shm_closed", "name": self.name,
                         "time": time.time()})

    def get_stats(self) -> dict:
        return {
            "writes": self.stats.writes,
            "reads": self.stats.reads,
            "bytes_written": self.stats.bytes_written,
            "lock_acquisitions": self.stats.lock_acquisitions,
            "lock_contentions": self.stats.lock_contentions,
            "avg_lock_wait": self.stats.avg_lock_wait,
            "max_lock_wait": self.stats.max_lock_wait,
            "counter_value": self.get_counter(),
        }
