"""
visualization_panel.py — Tkinter Canvas IPC Visualization
============================================================
Renders processes as circles and IPC channels as arrows on a Tkinter
``Canvas``.  Supports:

* Animated data-packet dots travelling along arrows.
* Color-coded channel types (blue = pipe, green = queue, orange = shm).
* Red pulsing highlights for deadlocks.
* Throughput-proportional arrow thickness.
"""

from __future__ import annotations

import math
import time
import tkinter as tk
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any


# ---------------------------------------------------------------------------
# Layout helpers
# ---------------------------------------------------------------------------

def _circle_pos(index: int, total: int,
                cx: float, cy: float, radius: float) -> Tuple[float, float]:
    """Place *index*-th node on a circle of *radius* around (cx, cy)."""
    angle = 2 * math.pi * index / max(total, 1) - math.pi / 2
    return cx + radius * math.cos(angle), cy + radius * math.sin(angle)


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

@dataclass
class NodeInfo:
    pid: int
    name: str
    x: float = 0.0
    y: float = 0.0
    canvas_id: int = 0
    label_id: int = 0
    state: str = "running"          # running | waiting | terminated


@dataclass
class EdgeInfo:
    channel_name: str
    src_pid: int
    dst_pid: int
    channel_type: str               # pipe | queue | shm
    canvas_id: int = 0
    label_id: int = 0
    packet_ids: List[int] = field(default_factory=list)
    highlighted: bool = False       # True during deadlock


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

_TYPE_COLORS = {"pipe": "#3498db", "queue": "#2ecc71", "shm": "#e67e22"}
_STATE_COLORS = {
    "running": "#2ecc71",
    "waiting": "#f1c40f",
    "terminated": "#95a5a6",
    "deadlocked": "#e74c3c",
}

NODE_RADIUS = 28


class VisualizationPanel:
    """
    Manages a ``tk.Canvas`` that displays processes and IPC channels.

    Call ``set_canvas(canvas)`` after the widget is created, then use
    ``add_node`` / ``add_edge`` / ``animate_packet`` to drive the display.
    """

    def __init__(self) -> None:
        self.canvas: Optional[tk.Canvas] = None
        self._nodes: Dict[int, NodeInfo] = {}
        self._edges: Dict[str, EdgeInfo] = {}
        self._alert_items: List[int] = []

    def set_canvas(self, canvas: tk.Canvas) -> None:
        self.canvas = canvas

    # -- nodes ---------------------------------------------------------------

    def add_node(self, pid: int, name: str,
                 x: Optional[float] = None,
                 y: Optional[float] = None) -> None:
        if self.canvas is None:
            return
        # Auto-layout if coords not given
        if x is None or y is None:
            cx = self.canvas.winfo_width() / 2 or 350
            cy = self.canvas.winfo_height() / 2 or 250
            idx = len(self._nodes)
            total = idx + 1
            x, y = _circle_pos(idx, total, cx, cy, min(cx, cy) * 0.6)
        node = NodeInfo(pid=pid, name=name, x=x, y=y)
        r = NODE_RADIUS
        node.canvas_id = self.canvas.create_oval(
            x - r, y - r, x + r, y + r,
            fill=_STATE_COLORS["running"], outline="white", width=2,
        )
        node.label_id = self.canvas.create_text(
            x, y, text=f"{name}\n(PID {pid})",
            font=("Helvetica", 8, "bold"), fill="white",
        )
        self._nodes[pid] = node

    def update_node_state(self, pid: int, state: str) -> None:
        node = self._nodes.get(pid)
        if node and self.canvas:
            node.state = state
            color = _STATE_COLORS.get(state, "#95a5a6")
            self.canvas.itemconfig(node.canvas_id, fill=color)

    def remove_node(self, pid: int) -> None:
        node = self._nodes.pop(pid, None)
        if node and self.canvas:
            self.canvas.delete(node.canvas_id)
            self.canvas.delete(node.label_id)

    # -- edges (channels) ----------------------------------------------------

    def add_edge(self, channel_name: str, src_pid: int, dst_pid: int,
                 channel_type: str = "pipe") -> None:
        if self.canvas is None:
            return
        src = self._nodes.get(src_pid)
        dst = self._nodes.get(dst_pid)
        if not src or not dst:
            return
        color = _TYPE_COLORS.get(channel_type, "gray")
        eid = self.canvas.create_line(
            src.x, src.y, dst.x, dst.y,
            arrow=tk.LAST, fill=color, width=2, dash=(6, 3),
        )
        mx, my = (src.x + dst.x) / 2, (src.y + dst.y) / 2 - 12
        lid = self.canvas.create_text(
            mx, my, text=f"{channel_name} ({channel_type})",
            font=("Helvetica", 7), fill=color,
        )
        edge = EdgeInfo(channel_name=channel_name,
                        src_pid=src_pid, dst_pid=dst_pid,
                        channel_type=channel_type,
                        canvas_id=eid, label_id=lid)
        self._edges[channel_name] = edge
        # Push edges behind nodes
        if eid:
            self.canvas.tag_lower(eid)
        if lid:
            self.canvas.tag_lower(lid)

    def highlight_edge(self, channel_name: str,
                       color: str = "#e74c3c") -> None:
        edge = self._edges.get(channel_name)
        if edge and self.canvas:
            self.canvas.itemconfig(edge.canvas_id, fill=color, width=4)
            edge.highlighted = True

    def unhighlight_edge(self, channel_name: str) -> None:
        edge = self._edges.get(channel_name)
        if edge and self.canvas:
            color = _TYPE_COLORS.get(edge.channel_type, "gray")
            self.canvas.itemconfig(edge.canvas_id, fill=color, width=2)
            edge.highlighted = False

    def remove_edge(self, channel_name: str) -> None:
        edge = self._edges.pop(channel_name, None)
        if edge and self.canvas:
            self.canvas.delete(edge.canvas_id)
            self.canvas.delete(edge.label_id)
            for pid in edge.packet_ids:
                self.canvas.delete(pid)

    # -- animated packets ----------------------------------------------------

    def animate_packet(self, channel_name: str,
                       duration_ms: int = 800) -> None:
        """
        Spawn a small coloured circle that travels from source to
        destination along the edge over *duration_ms* milliseconds.
        """
        edge = self._edges.get(channel_name)
        if not edge or not self.canvas:
            return
        src = self._nodes.get(edge.src_pid)
        dst = self._nodes.get(edge.dst_pid)
        if not src or not dst:
            return

        color = _TYPE_COLORS.get(edge.channel_type, "white")
        dot_r = 5
        dot = self.canvas.create_oval(
            src.x - dot_r, src.y - dot_r,
            src.x + dot_r, src.y + dot_r,
            fill=color, outline="white",
        )
        edge.packet_ids.append(dot)

        steps = max(1, duration_ms // 16)  # ~60 fps
        dx = (dst.x - src.x) / steps
        dy = (dst.y - src.y) / steps

        canvas = self.canvas  # local ref guaranteed non-None here

        def step(i: int = 0) -> None:
            if i >= steps:
                canvas.delete(dot)
                if dot in edge.packet_ids:
                    edge.packet_ids.remove(dot)
                return
            canvas.move(dot, dx, dy)
            canvas.after(16, lambda: step(i + 1))

        step()

    # -- deadlock alert ------------------------------------------------------

    def show_deadlock_alert(self, cycle_pids: List[int],
                            channel_names: List[str]) -> None:
        """Flash involved nodes red and highlight edges."""
        for pid in cycle_pids:
            self.update_node_state(pid, "deadlocked")
        for ch in channel_names:
            self.highlight_edge(ch, "#e74c3c")

        # Place a big red text in center
        if self.canvas:
            cx = self.canvas.winfo_width() / 2 or 350
            cy = 30
            tid = self.canvas.create_text(
                cx, cy, text="⚠ DEADLOCK DETECTED ⚠",
                font=("Helvetica", 16, "bold"), fill="#e74c3c",
            )
            self._alert_items.append(tid)

    def clear_alerts(self) -> None:
        if self.canvas:
            for item in self._alert_items:
                self.canvas.delete(item)
        self._alert_items.clear()
        for edge in self._edges.values():
            if edge.highlighted:
                self.unhighlight_edge(edge.channel_name)
        for node in self._nodes.values():
            if node.state == "deadlocked":
                self.update_node_state(node.pid, "running")

    # -- full redraw ---------------------------------------------------------

    def clear(self) -> None:
        if self.canvas:
            self.canvas.delete("all")
        self._nodes.clear()
        self._edges.clear()
        self._alert_items.clear()

    def relayout(self) -> None:
        """Recompute circular layout for all nodes and redraw edges."""
        if not self.canvas:
            return
        self.canvas.delete("all")
        cx = self.canvas.winfo_width() / 2 or 350
        cy = self.canvas.winfo_height() / 2 or 250
        total = len(self._nodes)
        old_edges = list(self._edges.values())
        old_nodes = list(self._nodes.values())
        self._nodes.clear()
        self._edges.clear()
        self._alert_items.clear()

        for idx, node in enumerate(old_nodes):
            x, y = _circle_pos(idx, total, cx, cy, min(cx, cy) * 0.55)
            self.add_node(node.pid, node.name, x, y)

        for edge in old_edges:
            self.add_edge(edge.channel_name, edge.src_pid,
                          edge.dst_pid, edge.channel_type)
