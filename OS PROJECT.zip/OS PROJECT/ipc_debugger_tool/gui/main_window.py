"""
main_window.py — IPC Debugger Tool — Main GUI
=================================================
Full Tkinter GUI featuring:

    ┌─────────────────────────────────────────────────────────┐
    │  Menu Bar                                               │
    ├────────────┬────────────────────────────────────────────┤
    │ Control    │                                            │
    │ Panel      │        Visualization Canvas                │
    │            │   (processes, channels, animations)        │
    │ - Process  │                                            │
    │   creation │                                            │
    │ - IPC type ├────────────────────────────────────────────┤
    │ - Start/   │        Real-Time Log Panel                 │
    │   Stop     │   (scrolling event log)                    │
    │ - Analyze  │                                            │
    └────────────┴────────────────────────────────────────────┘

Controls:
    • Add Process — creates a simulated process
    • IPC Type combo — Pipe / Message Queue / Shared Memory
    • Connect — creates an IPC channel between two selected processes
    • Start Simulation / Stop Simulation
    • Run Analysis — triggers deadlock / race / bottleneck detection
    • Inject Deadlock — creates a deliberate circular wait for demo
    • Clear — resets everything
"""

from __future__ import annotations

import time
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from typing import Optional, Dict, List, Any

from ipc_debugger_tool.engine.process_simulator import (
    ProcessSimulator, ProcessState,
)
from ipc_debugger_tool.engine.communication_simulator import CommunicationSimulator
from ipc_debugger_tool.analyzers.deadlock_detector import DeadlockDetector
from ipc_debugger_tool.analyzers.race_condition_detector import RaceConditionDetector
from ipc_debugger_tool.analyzers.bottleneck_detector import BottleneckDetector
from ipc_debugger_tool.utils.event_logger import EventLogger
from ipc_debugger_tool.utils.event_monitor import EventMonitor
from ipc_debugger_tool.visualization.visualization_panel import VisualizationPanel
from ipc_debugger_tool.visualization.animation_engine import AnimationEngine


# ---------------------------------------------------------------------------
# Worker functions that run in child processes
# ---------------------------------------------------------------------------

def _producer_worker(stop_event, queue_or_conn, pid, mode, on_event_ignore=None):
    """Generic producer: sends numbered messages until stopped."""
    import time, random, os
    i = 0
    while not stop_event.is_set():
        msg = f"msg-{i}-from-{pid}"
        try:
            if mode == "pipe":
                queue_or_conn.send(msg)
            elif mode == "queue":
                queue_or_conn.put(msg, timeout=1)
            elif mode == "shm":
                pass  # handled differently
        except Exception:
            break
        i += 1
        time.sleep(random.uniform(0.2, 0.6))


def _consumer_worker(stop_event, queue_or_conn, pid, mode, on_event_ignore=None):
    """Generic consumer: receives messages until stopped."""
    import time, os
    while not stop_event.is_set():
        try:
            if mode == "pipe":
                if queue_or_conn.poll(0.5):
                    _ = queue_or_conn.recv()
            elif mode == "queue":
                try:
                    _ = queue_or_conn.get(timeout=0.5)
                except Exception:
                    pass
            elif mode == "shm":
                pass
        except (EOFError, OSError):
            break
        time.sleep(0.05)


# ---------------------------------------------------------------------------
# Main Window
# ---------------------------------------------------------------------------

class MainWindow:
    """Top-level application window."""

    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title("IPC Debugger Tool — Inter-Process Communication Analyzer")
        self.root.geometry("1200x750")
        self.root.configure(bg="#1e1e2e")
        self.root.minsize(900, 600)

        # --- Core components ------------------------------------------------
        self.logger = EventLogger(
            log_dir="logs", on_log=self._on_log_event
        )
        self.process_sim = ProcessSimulator(on_event=self.logger.as_callback())
        self.comm_sim = CommunicationSimulator(on_event=self.logger.as_callback())

        self.deadlock_det = DeadlockDetector(
            auto_detect=False, on_event=self.logger.as_callback()
        )
        self.race_det = RaceConditionDetector(
            on_event=self.logger.as_callback()
        )
        self.bottleneck_det = BottleneckDetector(
            on_event=self.logger.as_callback()
        )
        self.event_monitor = EventMonitor(
            logger=self.logger,
            deadlock_detector=self.deadlock_det,
            race_detector=self.race_det,
            bottleneck_detector=self.bottleneck_det,
            on_alert=self._on_alert,
        )

        self.vis_panel = VisualizationPanel()
        self.anim_engine: Optional[AnimationEngine] = None

        # Track process counter for naming
        self._proc_counter = 0
        self._channel_counter = 0
        self._simulation_running = False

        # --- Build UI -------------------------------------------------------
        self._build_menu()
        self._build_layout()
        self._build_control_panel()
        self._build_canvas()
        self._build_log_panel()
        self._build_status_bar()

        # Wire animation engine
        self.anim_engine = AnimationEngine(self.vis_panel)

        self.logger.info("IPC Debugger Tool initialised.")

    # -----------------------------------------------------------------------
    # UI Construction
    # -----------------------------------------------------------------------

    def _build_menu(self) -> None:
        menubar = tk.Menu(self.root, bg="#2d2d44", fg="white",
                          activebackground="#44475a")
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Clear All", command=self._clear_all)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self._on_close)
        menubar.add_cascade(label="File", menu=file_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="About", command=self._show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        self.root.config(menu=menubar)

    def _build_layout(self) -> None:
        # Main horizontal pane
        self.main_pw = tk.PanedWindow(
            self.root, orient=tk.HORIZONTAL, bg="#1e1e2e",
            sashwidth=4, sashrelief=tk.RAISED,
        )
        self.main_pw.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # Left control panel frame
        self.ctrl_frame = tk.Frame(self.main_pw, bg="#2d2d44", width=260)
        self.main_pw.add(self.ctrl_frame, minsize=240)

        # Right vertical pane (canvas + log)
        self.right_pw = tk.PanedWindow(
            self.main_pw, orient=tk.VERTICAL, bg="#1e1e2e",
            sashwidth=4, sashrelief=tk.RAISED,
        )
        self.main_pw.add(self.right_pw)

    def _build_control_panel(self) -> None:
        fr = self.ctrl_frame
        pad: dict[str, Any] = {"padx": 8, "pady": 4, "sticky": "ew"}
        row = 0

        # -- Title
        tk.Label(fr, text="⚙  Controls", font=("Helvetica", 13, "bold"),
                 bg="#2d2d44", fg="#f8f8f2").grid(row=row, column=0,
                                                   columnspan=2, **pad)
        row += 1
        ttk.Separator(fr).grid(row=row, column=0, columnspan=2,
                                sticky="ew", pady=6)
        row += 1

        # -- Process creation
        tk.Label(fr, text="Process Name:", bg="#2d2d44",
                 fg="#ccc", font=("Helvetica", 10)).grid(
            row=row, column=0, **pad)
        self.proc_name_var = tk.StringVar(value="P1")
        tk.Entry(fr, textvariable=self.proc_name_var, width=14,
                 bg="#44475a", fg="white", insertbackground="white").grid(
            row=row, column=1, **pad)
        row += 1

        tk.Button(fr, text="➕  Add Process", command=self._add_process,
                  bg="#50fa7b", fg="black", activebackground="#69ff94",
                  font=("Helvetica", 10, "bold"), relief=tk.FLAT).grid(
            row=row, column=0, columnspan=2, **pad)
        row += 1
        ttk.Separator(fr).grid(row=row, column=0, columnspan=2,
                                sticky="ew", pady=6)
        row += 1

        # -- IPC Type
        tk.Label(fr, text="IPC Type:", bg="#2d2d44",
                 fg="#ccc", font=("Helvetica", 10)).grid(
            row=row, column=0, **pad)
        self.ipc_type_var = tk.StringVar(value="Pipe")
        ipc_combo = ttk.Combobox(fr, textvariable=self.ipc_type_var,
                                 values=["Pipe", "Message Queue",
                                         "Shared Memory"],
                                 state="readonly", width=14)
        ipc_combo.grid(row=row, column=1, **pad)
        row += 1

        # -- Endpoint selection
        tk.Label(fr, text="From (PID):", bg="#2d2d44",
                 fg="#ccc", font=("Helvetica", 10)).grid(
            row=row, column=0, **pad)
        self.from_pid_var = tk.StringVar()
        self.from_combo = ttk.Combobox(fr, textvariable=self.from_pid_var,
                                       state="readonly", width=14)
        self.from_combo.grid(row=row, column=1, **pad)
        row += 1

        tk.Label(fr, text="To (PID):", bg="#2d2d44",
                 fg="#ccc", font=("Helvetica", 10)).grid(
            row=row, column=0, **pad)
        self.to_pid_var = tk.StringVar()
        self.to_combo = ttk.Combobox(fr, textvariable=self.to_pid_var,
                                     state="readonly", width=14)
        self.to_combo.grid(row=row, column=1, **pad)
        row += 1

        tk.Button(fr, text="🔗  Connect", command=self._connect_channel,
                  bg="#8be9fd", fg="black", activebackground="#a4f0ff",
                  font=("Helvetica", 10, "bold"), relief=tk.FLAT).grid(
            row=row, column=0, columnspan=2, **pad)
        row += 1
        ttk.Separator(fr).grid(row=row, column=0, columnspan=2,
                                sticky="ew", pady=6)
        row += 1

        # -- Simulation controls
        self.start_btn = tk.Button(
            fr, text="▶  Start Simulation", command=self._start_simulation,
            bg="#50fa7b", fg="black", activebackground="#69ff94",
            font=("Helvetica", 10, "bold"), relief=tk.FLAT,
        )
        self.start_btn.grid(row=row, column=0, columnspan=2, **pad)
        row += 1

        self.stop_btn = tk.Button(
            fr, text="⏹  Stop Simulation", command=self._stop_simulation,
            bg="#ff5555", fg="white", activebackground="#ff6e6e",
            font=("Helvetica", 10, "bold"), relief=tk.FLAT,
            state=tk.DISABLED,
        )
        self.stop_btn.grid(row=row, column=0, columnspan=2, **pad)
        row += 1
        ttk.Separator(fr).grid(row=row, column=0, columnspan=2,
                                sticky="ew", pady=6)
        row += 1

        # -- Analysis
        tk.Button(fr, text="🔍  Run Analysis", command=self._run_analysis,
                  bg="#bd93f9", fg="white", activebackground="#caa8ff",
                  font=("Helvetica", 10, "bold"), relief=tk.FLAT).grid(
            row=row, column=0, columnspan=2, **pad)
        row += 1

        tk.Button(fr, text="💀  Inject Deadlock",
                  command=self._inject_deadlock,
                  bg="#ffb86c", fg="black", activebackground="#ffc98a",
                  font=("Helvetica", 10, "bold"), relief=tk.FLAT).grid(
            row=row, column=0, columnspan=2, **pad)
        row += 1

        tk.Button(fr, text="⚡  Send Test Data",
                  command=self._send_test_data,
                  bg="#8be9fd", fg="black", activebackground="#a4f0ff",
                  font=("Helvetica", 10, "bold"), relief=tk.FLAT).grid(
            row=row, column=0, columnspan=2, **pad)
        row += 1
        ttk.Separator(fr).grid(row=row, column=0, columnspan=2,
                                sticky="ew", pady=6)
        row += 1

        tk.Button(fr, text="🗑  Clear All", command=self._clear_all,
                  bg="#6272a4", fg="white", activebackground="#7b8dbd",
                  font=("Helvetica", 10), relief=tk.FLAT).grid(
            row=row, column=0, columnspan=2, **pad)
        row += 1

        fr.columnconfigure(0, weight=1)
        fr.columnconfigure(1, weight=1)

    def _build_canvas(self) -> None:
        canvas_frame = tk.Frame(self.right_pw, bg="#282a36")
        self.right_pw.add(canvas_frame, minsize=300)

        tk.Label(canvas_frame, text="📡  IPC Visualization",
                 font=("Helvetica", 11, "bold"),
                 bg="#282a36", fg="#f8f8f2").pack(anchor="w", padx=8, pady=4)

        self.canvas = tk.Canvas(canvas_frame, bg="#1e1e2e",
                                highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.vis_panel.set_canvas(self.canvas)

        # Legend
        legend_fr = tk.Frame(canvas_frame, bg="#282a36")
        legend_fr.pack(fill=tk.X, padx=8, pady=2)
        for label, color in [("Pipe", "#3498db"), ("Queue", "#2ecc71"),
                              ("SharedMem", "#e67e22"),
                              ("Deadlock", "#e74c3c")]:
            tk.Label(legend_fr, text=f"● {label}", fg=color,
                     bg="#282a36", font=("Helvetica", 9)).pack(
                side=tk.LEFT, padx=6)

    def _build_log_panel(self) -> None:
        log_frame = tk.Frame(self.right_pw, bg="#282a36")
        self.right_pw.add(log_frame, minsize=150)

        tk.Label(log_frame, text="📋  Event Log",
                 font=("Helvetica", 11, "bold"),
                 bg="#282a36", fg="#f8f8f2").pack(anchor="w", padx=8, pady=4)

        self.log_text = scrolledtext.ScrolledText(
            log_frame, height=8, bg="#1e1e2e", fg="#f8f8f2",
            font=("Courier", 9), state=tk.DISABLED,
            insertbackground="white", wrap=tk.WORD,
        )
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # Tag colours for different event types
        self.log_text.tag_config("info", foreground="#8be9fd")
        self.log_text.tag_config("warning", foreground="#ffb86c")
        self.log_text.tag_config("error", foreground="#ff5555")
        self.log_text.tag_config("deadlock", foreground="#ff5555",
                                 font=("Courier", 9, "bold"))
        self.log_text.tag_config("race", foreground="#ffb86c",
                                 font=("Courier", 9, "bold"))
        self.log_text.tag_config("bottleneck", foreground="#f1fa8c")
        self.log_text.tag_config("ipc", foreground="#50fa7b")

    def _build_status_bar(self) -> None:
        self.status_var = tk.StringVar(value="Ready")
        bar = tk.Label(self.root, textvariable=self.status_var,
                       bg="#44475a", fg="#f8f8f2", anchor="w",
                       font=("Helvetica", 9), padx=8)
        bar.pack(fill=tk.X, side=tk.BOTTOM)

    # -----------------------------------------------------------------------
    # Callbacks — Process & Channel management
    # -----------------------------------------------------------------------

    def _add_process(self) -> None:
        name = self.proc_name_var.get().strip()
        if not name:
            name = f"P{self._proc_counter + 1}"
        self._proc_counter += 1

        sp = self.process_sim.create_process(name=name)
        self.vis_panel.add_node(sp.pid, sp.name)
        self._refresh_pid_combos()
        self.logger.info(f"Process '{sp.name}' created (PID {sp.pid})")

        # Auto-increment suggested name
        self.proc_name_var.set(f"P{self._proc_counter + 1}")
        self.status_var.set(f"Process {sp.name} (PID {sp.pid}) added")

    def _refresh_pid_combos(self) -> None:
        pids = [f"{sp.pid} - {sp.name}"
                for sp in self.process_sim.get_all_processes()]
        self.from_combo["values"] = pids
        self.to_combo["values"] = pids

    def _parse_pid(self, combo_val: str) -> Optional[int]:
        try:
            return int(combo_val.split(" - ")[0])
        except (ValueError, IndexError):
            return None

    def _connect_channel(self) -> None:
        pid_a = self._parse_pid(self.from_pid_var.get())
        pid_b = self._parse_pid(self.to_pid_var.get())
        if pid_a is None or pid_b is None:
            messagebox.showwarning("Connect",
                                   "Select both From and To processes.")
            return
        if pid_a == pid_b:
            messagebox.showwarning("Connect",
                                   "Cannot connect a process to itself.")
            return

        ipc_type = self.ipc_type_var.get()
        self._channel_counter += 1
        ch_name = f"ch{self._channel_counter}"

        type_map = {
            "Pipe": "pipe",
            "Message Queue": "queue",
            "Shared Memory": "shm",
        }
        ctype = type_map.get(ipc_type, "pipe")

        if ctype == "pipe":
            self.comm_sim.create_pipe(ch_name, pid_a, pid_b)
        elif ctype == "queue":
            self.comm_sim.create_queue(ch_name, pid_a, pid_b, maxsize=20)
        elif ctype == "shm":
            self.comm_sim.create_shared_memory(ch_name, pid_a, pid_b)

        self.vis_panel.add_edge(ch_name, pid_a, pid_b, ctype)
        self.logger.info(
            f"Channel '{ch_name}' ({ipc_type}) created: "
            f"PID {pid_a} ↔ PID {pid_b}"
        )
        self.status_var.set(f"Channel {ch_name} ({ipc_type}) connected")

    # -----------------------------------------------------------------------
    # Simulation
    # -----------------------------------------------------------------------

    def _start_simulation(self) -> None:
        if self._simulation_running:
            return
        self._simulation_running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.event_monitor.start()
        if self.anim_engine:
            self.anim_engine.start(self.root)

        # Start a background thread that periodically sends test data
        self._sim_thread_stop = threading.Event()
        self._sim_thread = threading.Thread(
            target=self._simulation_loop, daemon=True
        )
        self._sim_thread.start()
        self.logger.info("Simulation STARTED")
        self.status_var.set("Simulation running…")

    def _simulation_loop(self) -> None:
        """Background loop: sends data through all channels periodically."""
        import random
        tick = 0
        while not self._sim_thread_stop.is_set():
            for ch in self.comm_sim.get_all_channels():
                try:
                    if ch.channel_type == "pipe":
                        self.comm_sim.send_via_pipe(
                            ch.name, f"data-{tick}", "a_to_b"
                        )
                        # Animate on the GUI thread
                        self.root.after(0, self.vis_panel.animate_packet,
                                        ch.name, 600)
                    elif ch.channel_type == "queue":
                        self.comm_sim.enqueue(ch.name, f"item-{tick}")
                        self.root.after(0, self.vis_panel.animate_packet,
                                        ch.name, 600)
                    elif ch.channel_type == "shm":
                        data = f"shm-{tick}".encode()[:1024]
                        self.comm_sim.shm_write(ch.name, data,
                                                pid=ch.endpoint_a)
                        self.root.after(0, self.vis_panel.animate_packet,
                                        ch.name, 600)
                except Exception:
                    pass
            tick += 1
            self._sim_thread_stop.wait(random.uniform(0.5, 1.5))

    def _stop_simulation(self) -> None:
        if not self._simulation_running:
            return
        self._simulation_running = False
        self._sim_thread_stop.set()
        self.event_monitor.stop()
        if self.anim_engine:
            self.anim_engine.stop()
        self.process_sim.stop_all()
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.logger.info("Simulation STOPPED")
        self.status_var.set("Simulation stopped")

    # -----------------------------------------------------------------------
    # Analysis
    # -----------------------------------------------------------------------

    def _run_analysis(self) -> None:
        self.logger.info("Running full analysis…")
        stats = self.comm_sim.get_all_stats()
        results = self.event_monitor.run_full_analysis(stats)

        # Deadlocks
        for dl in results["deadlocks"]:
            self.logger.log({"type": "deadlock_detected",
                             "message": str(dl),
                             "cycle": dl.cycle})
            self.vis_panel.show_deadlock_alert(dl.cycle, [])

        # Races
        for race in results["races"][-5:]:
            self.logger.log({"type": "race_detected",
                             "message": str(race)})

        # Bottlenecks
        for bn in results["bottlenecks"]:
            self.logger.log({"type": "bottleneck_detected",
                             "message": str(bn)})

        if not any(results.values()):
            self.logger.info("Analysis complete — no issues found.")
        self.status_var.set("Analysis complete")

    def _inject_deadlock(self) -> None:
        """Create a deliberate circular-wait for demonstration."""
        procs = self.process_sim.get_all_processes()
        if len(procs) < 2:
            messagebox.showinfo("Inject Deadlock",
                                "Need at least 2 processes to create a deadlock.")
            return

        self.deadlock_det.clear()
        # Create cycle: P0 → P1 → P2 → … → P0
        for i in range(len(procs)):
            waiter = procs[i].pid
            holder = procs[(i + 1) % len(procs)].pid
            self.deadlock_det.add_edge(waiter, holder,
                                       resource=f"R{i}")

        report = self.deadlock_det.detect()
        if report.detected:
            self.logger.log({
                "type": "deadlock_detected",
                "message": str(report),
                "cycle": report.cycle,
            })
            # Find channel names for the cycle edges (if any)
            ch_names = [e.channel_name for e in self.vis_panel._edges.values()]
            self.vis_panel.show_deadlock_alert(report.cycle, ch_names)
            self.status_var.set(f"DEADLOCK injected: {report}")
        else:
            self.logger.info("No deadlock formed (unexpected).")

    def _send_test_data(self) -> None:
        """Send one test message through every channel."""
        for ch in self.comm_sim.get_all_channels():
            try:
                if ch.channel_type == "pipe":
                    self.comm_sim.send_via_pipe(ch.name, "test-ping",
                                                "a_to_b")
                elif ch.channel_type == "queue":
                    self.comm_sim.enqueue(ch.name, "test-ping")
                elif ch.channel_type == "shm":
                    self.comm_sim.shm_write(ch.name, b"PING",
                                            pid=ch.endpoint_a)
                self.vis_panel.animate_packet(ch.name, 800)
            except Exception as exc:
                self.logger.error(f"Send failed on {ch.name}: {exc}")
        self.logger.info("Test data sent through all channels.")
        self.status_var.set("Test data sent")

    # -----------------------------------------------------------------------
    # Clear / Reset
    # -----------------------------------------------------------------------

    def _clear_all(self) -> None:
        self._stop_simulation()
        self.comm_sim.close_all()
        self.process_sim.clear()
        self.deadlock_det.clear()
        self.race_det.clear()
        self.bottleneck_det.clear()
        self.vis_panel.clear()
        self.logger.clear()
        self._proc_counter = 0
        self._channel_counter = 0
        self.proc_name_var.set("P1")
        self._refresh_pid_combos()

        # Clear log panel
        self.log_text.config(state=tk.NORMAL)
        self.log_text.delete("1.0", tk.END)
        self.log_text.config(state=tk.DISABLED)

        self.logger.info("All state cleared.")
        self.status_var.set("Cleared")

    # -----------------------------------------------------------------------
    # Log panel update (called from EventLogger callback)
    # -----------------------------------------------------------------------

    def _on_log_event(self, event: dict) -> None:
        """Append an event to the scrolled-text log (thread-safe)."""
        try:
            self.root.after(0, self._append_log, event)
        except RuntimeError:
            pass  # widget destroyed

    def _append_log(self, event: dict) -> None:
        ts = event.get("_ts", "")
        etype = event.get("type", "info")
        msg = event.get("message", "")
        if not msg:
            # Build a short summary from event fields
            parts = [f"{k}={v}" for k, v in event.items()
                     if k not in ("type", "time", "_ts")]
            msg = ", ".join(parts)

        tag = "info"
        if "deadlock" in etype:
            tag = "deadlock"
        elif "race" in etype:
            tag = "race"
        elif "bottleneck" in etype:
            tag = "bottleneck"
        elif etype in ("warning",):
            tag = "warning"
        elif etype in ("error",):
            tag = "error"
        elif etype.startswith(("pipe_", "queue_", "shm_", "channel_")):
            tag = "ipc"

        line = f"[{ts}] [{etype.upper():^22}]  {msg}\n"
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, line, tag)
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)

    def _on_alert(self, alert: dict) -> None:
        """Called by EventMonitor when an issue is found."""
        self._on_log_event({
            "type": alert.get("category", "warning"),
            "message": alert.get("message", ""),
            "time": alert.get("time", time.time()),
        })

    # -----------------------------------------------------------------------
    # Misc
    # -----------------------------------------------------------------------

    def _show_about(self) -> None:
        messagebox.showinfo(
            "About",
            "IPC Debugger Tool\n\n"
            "A debugging tool for Inter-Process Communication\n"
            "mechanisms (Pipes, Message Queues, Shared Memory).\n\n"
            "Detects deadlocks, race conditions, and bottlenecks\n"
            "with real-time visualization.\n\n"
            "Built with Python & Tkinter."
        )

    def _on_close(self) -> None:
        self._stop_simulation()
        self.comm_sim.close_all()
        self.logger.close()
        self.root.destroy()

    def run(self) -> None:
        """Start the Tkinter event loop."""
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.mainloop()
