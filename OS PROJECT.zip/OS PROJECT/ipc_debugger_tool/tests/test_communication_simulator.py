"""
test_communication_simulator.py — Integration tests for CommunicationSimulator
"""

import sys
import os
import time
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.engine.communication_simulator import CommunicationSimulator


class TestCommunicationSimulator:

    def test_pipe_channel(self):
        cs = CommunicationSimulator()
        cs.create_pipe("p1", 1000, 1001)
        cs.send_via_pipe("p1", "hello")
        result = cs.recv_via_pipe("p1", timeout=2.0)
        assert result == "hello"
        cs.close_all()

    def test_queue_channel(self):
        cs = CommunicationSimulator()
        cs.create_queue("q1", 1000, 1001)
        cs.enqueue("q1", "item1")
        result = cs.dequeue("q1", timeout=2.0)
        assert result == "item1"
        cs.close_all()

    def test_shm_channel(self):
        cs = CommunicationSimulator()
        cs.create_shared_memory("s1", 1000, 1001, size=256)
        cs.shm_write("s1", b"DATA", pid=1000)
        result = cs.shm_read("s1", 4, pid=1001)
        assert result == b"DATA"
        cs.close_all()

    def test_get_all_stats(self):
        cs = CommunicationSimulator()
        cs.create_pipe("p1", 1, 2)
        cs.create_queue("q1", 3, 4)
        cs.send_via_pipe("p1", "x")
        cs.enqueue("q1", "y")
        stats = cs.get_all_stats()
        assert "p1" in stats
        assert "q1" in stats
        assert stats["p1"]["type"] == "pipe"
        assert stats["q1"]["type"] == "queue"
        cs.close_all()

    def test_close_channel(self):
        cs = CommunicationSimulator()
        cs.create_pipe("p1", 1, 2)
        cs.close_channel("p1")
        assert cs.get_channel("p1") is None

    def test_events(self):
        events = []
        cs = CommunicationSimulator(on_event=lambda e: events.append(e))
        cs.create_pipe("p1", 1, 2)
        cs.send_via_pipe("p1", "msg")
        types = [e["type"] for e in events]
        assert "channel_created" in types
        assert "pipe_send" in types
        cs.close_all()
