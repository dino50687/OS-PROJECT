"""
test_ipc_message_queue.py — Unit tests for MessageQueueCommunicator
"""

import sys
import os
import time
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.ipc.ipc_message_queue import MessageQueueCommunicator


class TestMessageQueueCommunicator:

    def test_enqueue_dequeue(self):
        mq = MessageQueueCommunicator()
        mq.enqueue("msg1", sender_pid=1)
        mq.enqueue("msg2", sender_pid=1)
        r1 = mq.dequeue(receiver_pid=2, timeout=2.0)
        r2 = mq.dequeue(receiver_pid=2, timeout=2.0)
        assert r1 == "msg1"
        assert r2 == "msg2"
        mq.close()

    def test_stats(self):
        mq = MessageQueueCommunicator()
        for i in range(3):
            mq.enqueue(i)
        for _ in range(3):
            mq.dequeue(timeout=2.0)
        stats = mq.get_stats()
        assert stats["messages_enqueued"] == 3
        assert stats["messages_dequeued"] == 3
        mq.close()

    def test_dequeue_timeout(self):
        mq = MessageQueueCommunicator()
        result = mq.dequeue(timeout=0.1)
        assert result is None
        assert mq.stats.empty_events == 1
        mq.close()

    def test_maxsize_blocking(self):
        """With maxsize=2, the third enqueue should raise on timeout."""
        mq = MessageQueueCommunicator(maxsize=2)
        mq.enqueue("a")
        mq.enqueue("b")
        with pytest.raises(Exception):
            mq.enqueue("c", timeout=0.2)  # should block then raise Full
        mq.close()

    def test_events(self):
        events = []
        mq = MessageQueueCommunicator(on_event=lambda e: events.append(e))
        mq.enqueue("x")
        mq.dequeue(timeout=1.0)
        mq.close()
        types = [e["type"] for e in events]
        assert "queue_enqueue" in types
        assert "queue_dequeue" in types
