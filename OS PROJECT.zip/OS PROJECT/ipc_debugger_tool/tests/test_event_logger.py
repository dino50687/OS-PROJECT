"""
test_event_logger.py — Unit tests for EventLogger
"""

import sys
import os
import json
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.utils.event_logger import EventLogger


class TestEventLogger:

    def test_log_and_retrieve(self, tmp_path):
        logger = EventLogger(log_dir=str(tmp_path))
        logger.log({"type": "info", "message": "test1"})
        logger.log({"type": "warning", "message": "test2"})
        events = logger.get_all()
        assert len(events) == 2
        assert events[0]["message"] == "test1"
        logger.close()

    def test_get_recent(self, tmp_path):
        logger = EventLogger(log_dir=str(tmp_path))
        for i in range(10):
            logger.log({"type": "info", "message": f"m{i}"})
        recent = logger.get_recent(3)
        assert len(recent) == 3
        assert recent[0]["message"] == "m7"
        logger.close()

    def test_get_by_type(self, tmp_path):
        logger = EventLogger(log_dir=str(tmp_path))
        logger.info("a")
        logger.warning("b")
        logger.error("c")
        logger.info("d")
        warnings = logger.get_by_type("warning")
        assert len(warnings) == 1
        logger.close()

    def test_file_persistence(self, tmp_path):
        logger = EventLogger(log_dir=str(tmp_path))
        logger.info("persisted")
        logger.close()
        with open(logger.log_path, "r") as f:
            lines = f.readlines()
        assert len(lines) == 1
        data = json.loads(lines[0])
        assert data["message"] == "persisted"

    def test_callback(self, tmp_path):
        called = []
        logger = EventLogger(log_dir=str(tmp_path),
                              on_log=lambda e: called.append(e))
        logger.info("cb_test")
        assert len(called) == 1
        logger.close()

    def test_clear(self, tmp_path):
        logger = EventLogger(log_dir=str(tmp_path))
        logger.info("x")
        logger.clear()
        assert len(logger.get_all()) == 0
        logger.close()
