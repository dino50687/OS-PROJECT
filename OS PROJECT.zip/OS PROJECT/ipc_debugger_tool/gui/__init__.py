"""
GUI Package
============
Tkinter-based graphical user interface:
  - MainWindow — the top-level application window with all controls
"""

from .main_window import MainWindow

__all__ = ["MainWindow"]
