"""
process_simulator.py — Virtual Process Manager
=================================================
Spawns and manages simulated OS processes using Python's
``multiprocessing`` module.  Each simulated process runs a configurable
*task function* that performs IPC operations.

The simulator tracks process state (READY → RUNNING → WAITING → TERMINATED)
and exposes the information to the GUI and analyzers.
"""

from __future__ import annotations

import os
import time
import multiprocessing
from multiprocessing import Process, Event as MpEvent
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Any


class ProcessState(Enum):
    READY = auto()
    RUNNING = auto()
    WAITING = auto()
    TERMINATED = auto()


@dataclass
class SimulatedProcess:
    """Metadata about one simulated process."""
    pid: int
    name: str
    state: ProcessState = ProcessState.READY
    process: Optional[Process] = field(default=None, repr=False)
    stop_event: Optional[Any] = field(default=None, repr=False)
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    error: Optional[str] = None

    @property
    def elapsed(self) -> float:
        if self.start_time is None:
            return 0.0
        end = self.end_time or time.time()
        return end - self.start_time


class ProcessSimulator:
    """
    Creates, starts, monitors, and terminates simulated processes.

    Parameters
    ----------
    on_event : callable, optional
        Callback ``on_event(event_dict)`` for the event logger.
    """

    def __init__(self, on_event: Optional[Callable] = None):
        self._processes: Dict[int, SimulatedProcess] = {}
        self._next_id: int = 1000   # virtual PID counter
        self._on_event = on_event

    def _emit(self, event: dict) -> None:
        if self._on_event:
            try:
                self._on_event(event)
            except Exception:
                pass

    # -- creation ------------------------------------------------------------

    def create_process(self, name: str,
                       target: Optional[Callable] = None,
                       args: tuple = (),
                       kwargs: Optional[dict] = None) -> SimulatedProcess:
        """
        Register a new simulated process.

        Parameters
        ----------
        name : str
            Human-readable name (shown in GUI).
        target : callable, optional
            The function the process will execute.  It will receive a
            ``stop_event`` as its first argument, followed by *args* and
            **kwargs*.
        args : tuple
            Positional arguments forwarded to *target*.
        kwargs : dict, optional
            Keyword arguments forwarded to *target*.

        Returns
        -------
        SimulatedProcess
        """
        pid = self._next_id
        self._next_id += 1
        stop_event = MpEvent()
        kwargs = kwargs or {}

        if target is not None:
            proc = Process(
                target=target,
                args=(stop_event, *args),
                kwargs=kwargs,
                daemon=True,
                name=name,
            )
        else:
            proc = None

        sp = SimulatedProcess(pid=pid, name=name,
                              process=proc, stop_event=stop_event)
        self._processes[pid] = sp
        self._emit({
            "type": "process_created",
            "pid": pid,
            "name": name,
            "time": time.time(),
        })
        return sp

    # -- lifecycle -----------------------------------------------------------

    def start_process(self, pid: int) -> None:
        sp = self._processes.get(pid)
        if sp is None:
            raise KeyError(f"No process with PID {pid}")
        if sp.process is None:
            raise RuntimeError("Process has no target function")
        sp.process.start()
        sp.state = ProcessState.RUNNING
        sp.start_time = time.time()
        self._emit({
            "type": "process_started",
            "pid": pid,
            "name": sp.name,
            "time": sp.start_time,
        })

    def stop_process(self, pid: int, timeout: float = 2.0) -> None:
        sp = self._processes.get(pid)
        if sp is None:
            return
        if sp.stop_event is not None:
            sp.stop_event.set()
        if sp.process is not None and sp.process.is_alive():
            sp.process.join(timeout=timeout)
            if sp.process.is_alive():
                sp.process.terminate()
                sp.process.join(timeout=1.0)
        sp.state = ProcessState.TERMINATED
        sp.end_time = time.time()
        self._emit({
            "type": "process_stopped",
            "pid": pid,
            "name": sp.name,
            "time": sp.end_time,
        })

    def start_all(self) -> None:
        for pid, sp in self._processes.items():
            if sp.state == ProcessState.READY and sp.process is not None:
                self.start_process(pid)

    def stop_all(self, timeout: float = 2.0) -> None:
        for pid in list(self._processes):
            sp = self._processes[pid]
            if sp.state == ProcessState.RUNNING:
                self.stop_process(pid, timeout)

    # -- queries -------------------------------------------------------------

    def get_process(self, pid: int) -> Optional[SimulatedProcess]:
        return self._processes.get(pid)

    def get_all_processes(self) -> List[SimulatedProcess]:
        return list(self._processes.values())

    def get_running(self) -> List[SimulatedProcess]:
        return [p for p in self._processes.values()
                if p.state == ProcessState.RUNNING]

    def refresh_states(self) -> None:
        """Update states by checking if underlying OS processes are alive."""
        for sp in self._processes.values():
            if sp.state == ProcessState.RUNNING:
                if sp.process is not None and not sp.process.is_alive():
                    sp.state = ProcessState.TERMINATED
                    sp.end_time = time.time()

    def remove_process(self, pid: int) -> None:
        sp = self._processes.pop(pid, None)
        if sp and sp.state == ProcessState.RUNNING:
            self.stop_process(pid)

    def clear(self) -> None:
        self.stop_all()
        self._processes.clear()
