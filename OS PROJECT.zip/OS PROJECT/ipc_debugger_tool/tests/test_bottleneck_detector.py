"""
test_bottleneck_detector.py — Unit tests for BottleneckDetector
"""

import sys
import os
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.analyzers.bottleneck_detector import BottleneckDetector


class TestBottleneckDetector:

    def test_queue_congestion(self):
        bd = BottleneckDetector(queue_depth_threshold=5)
        stats = {"current_size": 10, "messages_enqueued": 20,
                 "messages_dequeued": 10}
        reports = bd.analyze_queue("q1", stats)
        categories = [r.category for r in reports]
        assert "queue_congestion" in categories

    def test_slow_consumer(self):
        bd = BottleneckDetector(consumer_lag_ratio=0.3)
        stats = {"current_size": 2, "messages_enqueued": 100,
                 "messages_dequeued": 50}
        reports = bd.analyze_queue("q1", stats)
        categories = [r.category for r in reports]
        assert "slow_consumer" in categories

    def test_pipe_blocked(self):
        bd = BottleneckDetector(pipe_block_threshold=3)
        stats = {"blocked_count": 10, "max_latency": 0.5}
        reports = bd.analyze_pipe("p1", stats)
        assert any(r.category == "pipe_blocked" for r in reports)

    def test_lock_contention(self):
        bd = BottleneckDetector(lock_wait_threshold=0.05)
        stats = {"max_lock_wait": 0.1, "lock_contentions": 10}
        reports = bd.analyze_shared_memory("shm1", stats)
        assert any(r.category == "lock_contention" for r in reports)

    def test_no_bottleneck(self):
        bd = BottleneckDetector()
        stats = {"current_size": 0, "messages_enqueued": 5,
                 "messages_dequeued": 5}
        reports = bd.analyze_queue("q1", stats)
        assert len(reports) == 0

    def test_analyze_all(self):
        bd = BottleneckDetector(queue_depth_threshold=2)
        channels = {
            "q1": {"type": "queue", "stats": {
                "current_size": 5, "messages_enqueued": 10,
                "messages_dequeued": 5}},
            "p1": {"type": "pipe", "stats": {
                "blocked_count": 0, "max_latency": 0.01}},
        }
        reports = bd.analyze_all(channels)
        assert len(reports) >= 1

    def test_history(self):
        bd = BottleneckDetector(queue_depth_threshold=1)
        bd.analyze_queue("q1", {"current_size": 5,
                                 "messages_enqueued": 5,
                                 "messages_dequeued": 0})
        assert len(bd.get_history()) >= 1
        bd.clear()
        assert len(bd.get_history()) == 0
