"""
bottleneck_detector.py — IPC Throughput & Latency Analyzer
============================================================
Identifies performance bottlenecks in IPC channels:

* **Queue congestion** — queue depth exceeds a configurable high-water mark.
* **Blocked pipes** — send / recv blocking events above a threshold.
* **Shared-memory lock contention** — lock wait times exceed a threshold.
* **Slow consumer** — message consumption rate lags behind production rate
  beyond a configurable ratio.

Metrics used
------------
* **Latency** — time between send and corresponding recv (per message).
* **Throughput** — messages / second over a sliding window.
* **Queue depth** — current items waiting in a message queue.
* **Lock wait time** — time spent waiting to acquire a shared-memory lock.
* **Block count** — number of times an operation blocked.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from typing import List, Optional, Callable, Deque


@dataclass
class BottleneckReport:
    category: str      # "queue_congestion", "pipe_blocked",
                       # "lock_contention", "slow_consumer"
    channel: str       # logical name of the IPC channel
    metric_name: str   # e.g. "queue_depth", "lock_wait_ms"
    metric_value: float
    threshold: float
    message: str
    timestamp: float = field(default_factory=time.time)

    def __str__(self) -> str:
        return f"BOTTLENECK [{self.category}] {self.channel}: {self.message}"


class BottleneckDetector:
    """
    Collects IPC statistics snapshots and checks them against configurable
    thresholds to flag bottlenecks.

    Parameters
    ----------
    queue_depth_threshold : int
        Queue depth above which *queue_congestion* is reported.
    pipe_block_threshold : int
        Number of blocking events above which *pipe_blocked* is reported.
    lock_wait_threshold : float
        Lock wait time (seconds) above which *lock_contention* is reported.
    consumer_lag_ratio : float
        If  (enqueued - dequeued) / enqueued  exceeds this ratio, flag
        *slow_consumer*.
    on_bottleneck : callable, optional
        ``on_bottleneck(BottleneckReport)`` callback.
    on_event : callable, optional
        Generic event callback.
    """

    def __init__(
        self,
        queue_depth_threshold: int = 10,
        pipe_block_threshold: int = 5,
        lock_wait_threshold: float = 0.1,
        consumer_lag_ratio: float = 0.5,
        on_bottleneck: Optional[Callable] = None,
        on_event: Optional[Callable] = None,
    ):
        self.queue_depth_threshold = queue_depth_threshold
        self.pipe_block_threshold = pipe_block_threshold
        self.lock_wait_threshold = lock_wait_threshold
        self.consumer_lag_ratio = consumer_lag_ratio
        self._on_bottleneck = on_bottleneck
        self._on_event = on_event
        self._history: List[BottleneckReport] = []

        # Throughput tracking: sliding window of (timestamp, count)
        self._throughput_window: Deque = deque(maxlen=100)

    def _emit(self, event: dict) -> None:
        if self._on_event:
            try:
                self._on_event(event)
            except Exception:
                pass

    def _report(self, category: str, channel: str,
                metric_name: str, metric_value: float,
                threshold: float, message: str) -> BottleneckReport:
        r = BottleneckReport(
            category=category, channel=channel,
            metric_name=metric_name, metric_value=metric_value,
            threshold=threshold, message=message,
        )
        self._history.append(r)
        self._emit({
            "type": "bottleneck_detected",
            "category": category,
            "channel": channel,
            "metric": metric_name,
            "value": metric_value,
            "threshold": threshold,
            "time": r.timestamp,
        })
        if self._on_bottleneck:
            try:
                self._on_bottleneck(r)
            except Exception:
                pass
        return r

    # -- Analysis entry points -----------------------------------------------

    def analyze_queue(self, channel: str,
                      stats: dict) -> List[BottleneckReport]:
        """Analyze message-queue stats dict."""
        reports: List[BottleneckReport] = []
        depth = stats.get("current_size", 0)
        if depth > self.queue_depth_threshold:
            reports.append(self._report(
                "queue_congestion", channel,
                "queue_depth", depth, self.queue_depth_threshold,
                f"Queue depth {depth} exceeds threshold "
                f"{self.queue_depth_threshold}",
            ))

        enqueued = stats.get("messages_enqueued", 0)
        dequeued = stats.get("messages_dequeued", 0)
        if enqueued > 0:
            lag = (enqueued - dequeued) / enqueued
            if lag > self.consumer_lag_ratio:
                reports.append(self._report(
                    "slow_consumer", channel,
                    "consumer_lag_ratio", lag, self.consumer_lag_ratio,
                    f"Consumer lag {lag:.1%} exceeds threshold "
                    f"{self.consumer_lag_ratio:.1%}",
                ))
        return reports

    def analyze_pipe(self, channel: str,
                     stats: dict) -> List[BottleneckReport]:
        """Analyze pipe stats dict."""
        reports: List[BottleneckReport] = []
        blocked = stats.get("blocked_count", 0)
        if blocked > self.pipe_block_threshold:
            reports.append(self._report(
                "pipe_blocked", channel,
                "blocked_count", blocked, self.pipe_block_threshold,
                f"Pipe blocked {blocked} times "
                f"(threshold {self.pipe_block_threshold})",
            ))

        max_lat = stats.get("max_latency", 0)
        if max_lat > 1.0:
            reports.append(self._report(
                "pipe_blocked", channel,
                "max_latency", max_lat, 1.0,
                f"Pipe max latency {max_lat:.3f}s exceeds 1 s",
            ))
        return reports

    def analyze_shared_memory(self, channel: str,
                              stats: dict) -> List[BottleneckReport]:
        """Analyze shared-memory stats dict."""
        reports: List[BottleneckReport] = []
        lock_wait = stats.get("max_lock_wait", 0)
        if lock_wait > self.lock_wait_threshold:
            reports.append(self._report(
                "lock_contention", channel,
                "max_lock_wait", lock_wait, self.lock_wait_threshold,
                f"Lock contention: max wait {lock_wait:.3f}s "
                f"(threshold {self.lock_wait_threshold:.3f}s)",
            ))
        contentions = stats.get("lock_contentions", 0)
        if contentions > 5:
            reports.append(self._report(
                "lock_contention", channel,
                "lock_contentions", contentions, 5,
                f"Lock contended {contentions} times",
            ))
        return reports

    def analyze_all(self, channels: dict) -> List[BottleneckReport]:
        """
        Convenience: analyze all channels at once.

        *channels* maps ``channel_name → {"type": "pipe"|"queue"|"shm",
        "stats": {...}}``.
        """
        all_reports: List[BottleneckReport] = []
        for name, info in channels.items():
            ctype = info.get("type", "")
            stats = info.get("stats", {})
            if ctype == "pipe":
                all_reports.extend(self.analyze_pipe(name, stats))
            elif ctype == "queue":
                all_reports.extend(self.analyze_queue(name, stats))
            elif ctype == "shm":
                all_reports.extend(self.analyze_shared_memory(name, stats))
        return all_reports

    # -- Throughput measurement ---------------------------------------------

    def record_throughput_sample(self, count: int) -> None:
        self._throughput_window.append((time.time(), count))

    def get_throughput(self) -> float:
        """Messages/second over the sliding window."""
        if len(self._throughput_window) < 2:
            return 0.0
        first_t, first_c = self._throughput_window[0]
        last_t, last_c = self._throughput_window[-1]
        dt = last_t - first_t
        if dt == 0:
            return 0.0
        return (last_c - first_c) / dt

    def get_history(self) -> List[BottleneckReport]:
        return list(self._history)

    def clear(self) -> None:
        self._history.clear()
        self._throughput_window.clear()
