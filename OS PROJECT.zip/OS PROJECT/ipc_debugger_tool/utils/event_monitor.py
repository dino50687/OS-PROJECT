"""
event_monitor.py — Real-time Event Dispatcher
=================================================
Watches the ``EventLogger`` buffer and dispatches events to registered
analyzers (deadlock detector, race-condition detector, bottleneck
detector) as they arrive.

Runs in a background thread, polling the logger at a configurable
interval.
"""

from __future__ import annotations

import time
import threading
from typing import Optional, Callable, List, Dict, Any

from ipc_debugger_tool.utils.event_logger import EventLogger
from ipc_debugger_tool.analyzers.deadlock_detector import DeadlockDetector
from ipc_debugger_tool.analyzers.race_condition_detector import RaceConditionDetector
from ipc_debugger_tool.analyzers.bottleneck_detector import BottleneckDetector


class EventMonitor:
    """
    Bridges the event logger and the analyzers.

    Parameters
    ----------
    logger : EventLogger
    deadlock_detector : DeadlockDetector, optional
    race_detector : RaceConditionDetector, optional
    bottleneck_detector : BottleneckDetector, optional
    poll_interval : float
        Seconds between buffer polls (default 0.1).
    on_alert : callable, optional
        ``on_alert(alert_dict)`` invoked for every issue found.
    """

    def __init__(
        self,
        logger: EventLogger,
        deadlock_detector: Optional[DeadlockDetector] = None,
        race_detector: Optional[RaceConditionDetector] = None,
        bottleneck_detector: Optional[BottleneckDetector] = None,
        poll_interval: float = 0.1,
        on_alert: Optional[Callable] = None,
    ):
        self.logger = logger
        self.deadlock_detector = deadlock_detector
        self.race_detector = race_detector
        self.bottleneck_detector = bottleneck_detector
        self.poll_interval = poll_interval
        self._on_alert = on_alert

        self._cursor = 0  # how many events have been processed
        self._running = False
        self._thread: Optional[threading.Thread] = None

    # -- background thread ---------------------------------------------------

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True,
                                        name="EventMonitor")
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)
            self._thread = None

    def _run(self) -> None:
        while self._running:
            self._poll()
            time.sleep(self.poll_interval)

    # -- poll & dispatch -----------------------------------------------------

    def _poll(self) -> None:
        events = self.logger.get_all()
        new_events = events[self._cursor:]
        self._cursor = len(events)

        for event in new_events:
            self._dispatch(event)

    def _dispatch(self, event: Dict[str, Any]) -> None:
        etype = event.get("type", "")

        # --- Feed deadlock detector ---
        if etype == "shm_lock_acquire" and self.deadlock_detector:
            pid = event.get("pid", 0)
            # We model lock contention as a wait-for edge
            if event.get("contended"):
                self.deadlock_detector.add_edge(
                    waiter=pid, holder=0, resource="shm_lock"
                )
        if etype == "shm_lock_release" and self.deadlock_detector:
            pid = event.get("pid", 0)
            self.deadlock_detector.remove_edge(waiter=pid, holder=0)

        # --- Feed race condition detector ---
        if etype in ("shm_write", "shm_read") and self.race_detector:
            mode = "write" if etype == "shm_write" else "read"
            pid = event.get("pid", 0)
            resource = f"shm@{event.get('offset', 0)}"
            locked = False  # caller must indicate; heuristic here
            self.race_detector.record_access(
                pid=pid, resource=resource, mode=mode, locked=locked
            )

        # --- Feed bottleneck detector (throughput samples) ---
        if etype in ("queue_enqueue", "queue_dequeue") and self.bottleneck_detector:
            self.bottleneck_detector.record_throughput_sample(1)

    # -- manual trigger ------------------------------------------------------

    def run_full_analysis(self, channel_stats: Dict[str, dict]) -> Dict[str, list]:
        """
        Run all detectors once and return their reports.

        Parameters
        ----------
        channel_stats : dict
            Output of ``CommunicationSimulator.get_all_stats()``.

        Returns
        -------
        dict with keys ``deadlocks``, ``races``, ``bottlenecks``.
        """
        results: Dict[str, list] = {
            "deadlocks": [],
            "races": [],
            "bottlenecks": [],
        }
        if self.deadlock_detector:
            report = self.deadlock_detector.detect()
            if report.detected:
                results["deadlocks"].append(report)
                self._alert("deadlock", str(report))

        if self.race_detector:
            results["races"] = self.race_detector.get_history()

        if self.bottleneck_detector:
            results["bottlenecks"] = self.bottleneck_detector.analyze_all(
                channel_stats
            )
            for b in results["bottlenecks"]:
                self._alert("bottleneck", str(b))

        return results

    def _alert(self, category: str, message: str) -> None:
        if self._on_alert:
            try:
                self._on_alert({
                    "category": category,
                    "message": message,
                    "time": time.time(),
                })
            except Exception:
                pass
