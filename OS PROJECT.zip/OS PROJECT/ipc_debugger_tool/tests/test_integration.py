"""
test_integration.py — End-to-end integration & stress tests
=============================================================
Tests that simulate realistic IPC scenarios involving multiple
components working together.
"""

import sys
import os
import time
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.engine.process_simulator import ProcessSimulator
from ipc_debugger_tool.engine.communication_simulator import CommunicationSimulator
from ipc_debugger_tool.analyzers.deadlock_detector import DeadlockDetector
from ipc_debugger_tool.analyzers.race_condition_detector import RaceConditionDetector
from ipc_debugger_tool.analyzers.bottleneck_detector import BottleneckDetector
from ipc_debugger_tool.utils.event_logger import EventLogger
from ipc_debugger_tool.utils.event_monitor import EventMonitor


class TestIntegration:
    """Full pipeline integration tests."""

    def test_pipe_scenario(self, tmp_path):
        """Producer sends through pipe, consumer receives, stats correct."""
        logger = EventLogger(log_dir=str(tmp_path))
        cs = CommunicationSimulator(on_event=logger.as_callback())
        cs.create_pipe("p1", 1000, 1001)

        for i in range(10):
            cs.send_via_pipe("p1", f"msg-{i}")
        for i in range(10):
            result = cs.recv_via_pipe("p1", timeout=2.0)
            assert result == f"msg-{i}"

        stats = cs.get_stats("p1")
        assert stats["messages_sent"] == 10
        assert stats["messages_received"] == 10
        cs.close_all()
        logger.close()

    def test_queue_scenario(self, tmp_path):
        logger = EventLogger(log_dir=str(tmp_path))
        cs = CommunicationSimulator(on_event=logger.as_callback())
        cs.create_queue("q1", 1000, 1001, maxsize=20)

        for i in range(15):
            cs.enqueue("q1", f"item-{i}")
        for i in range(15):
            result = cs.dequeue("q1", timeout=2.0)
            assert result == f"item-{i}"

        stats = cs.get_stats("q1")
        assert stats["messages_enqueued"] == 15
        assert stats["messages_dequeued"] == 15
        cs.close_all()
        logger.close()

    def test_deadlock_scenario(self):
        """Inject a 3-way deadlock and verify detection."""
        dd = DeadlockDetector(auto_detect=False)
        dd.add_edge(1, 2, "R1")
        dd.add_edge(2, 3, "R2")
        dd.add_edge(3, 1, "R3")
        report = dd.detect()
        assert report.detected
        assert set(report.cycle) == {1, 2, 3}

    def test_race_condition_scenario(self):
        """Two processes write to same resource concurrently."""
        rd = RaceConditionDetector(window=1.0)
        rd.record_access(pid=100, resource="counter",
                          mode="write", locked=False)
        races = rd.record_access(pid=200, resource="counter",
                                  mode="write", locked=False)
        assert len(races) == 1
        assert races[0].resource == "counter"

    def test_bottleneck_after_simulation(self, tmp_path):
        """Queue fills up → bottleneck detector flags it."""
        logger = EventLogger(log_dir=str(tmp_path))
        bd = BottleneckDetector(queue_depth_threshold=5)
        cs = CommunicationSimulator(on_event=logger.as_callback())
        cs.create_queue("q1", 1, 2, maxsize=50)

        # Enqueue many, dequeue few → congestion
        for i in range(20):
            cs.enqueue("q1", f"x{i}")
        for i in range(5):
            cs.dequeue("q1", timeout=1.0)

        stats = cs.get_all_stats()
        reports = bd.analyze_all(stats)
        categories = [r.category for r in reports]
        assert "queue_congestion" in categories or "slow_consumer" in categories
        cs.close_all()
        logger.close()

    def test_event_monitor_integration(self, tmp_path):
        """EventMonitor dispatches events to analyzers."""
        logger = EventLogger(log_dir=str(tmp_path))
        dd = DeadlockDetector(auto_detect=False)
        rd = RaceConditionDetector(window=1.0)
        bd = BottleneckDetector()

        monitor = EventMonitor(
            logger=logger,
            deadlock_detector=dd,
            race_detector=rd,
            bottleneck_detector=bd,
        )

        # Log some events
        logger.log({"type": "shm_write", "pid": 1, "offset": 0})
        logger.log({"type": "shm_write", "pid": 2, "offset": 0})
        logger.log({"type": "queue_enqueue"})

        # Run a poll cycle
        monitor._poll()

        # The race detector should have seen 2 writes
        # (depending on timing within the window)
        assert rd.get_monitored_resources()  # at least one resource seen

        logger.close()

    def test_stress_many_messages(self, tmp_path):
        """Send 100 messages through a pipe without errors."""
        cs = CommunicationSimulator()
        cs.create_pipe("stress_pipe", 1, 2)
        n = 100
        for i in range(n):
            cs.send_via_pipe("stress_pipe", i)
        for i in range(n):
            result = cs.recv_via_pipe("stress_pipe", timeout=5.0)
            assert result == i
        stats = cs.get_stats("stress_pipe")
        assert stats["messages_sent"] == n
        assert stats["messages_received"] == n
        cs.close_all()
