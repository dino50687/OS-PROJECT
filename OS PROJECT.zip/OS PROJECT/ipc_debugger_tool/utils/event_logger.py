"""
event_logger.py — Thread-Safe Event Logger
=============================================
Centralized logging system that:
    1. Writes structured events to an in-memory ring buffer (for the GUI).
    2. Persists events to a rotating log file under ``logs/``.
    3. Provides a callback hook so the GUI can update its log panel in
       real time.

All methods are thread-safe (guarded by ``threading.Lock``).
"""

from __future__ import annotations

import os
import json
import time
import threading
from collections import deque
from datetime import datetime
from typing import Deque, Dict, List, Optional, Callable, Any


class EventLogger:
    """
    Parameters
    ----------
    log_dir : str
        Directory for log files (created if missing).
    max_memory_events : int
        Maximum events kept in the in-memory ring buffer.
    on_log : callable, optional
        ``on_log(event_dict)`` called for every logged event — typically
        wired to the GUI log panel.
    """

    _EVENT_TYPES = {
        # IPC
        "pipe_send", "pipe_recv", "pipe_blocked", "pipe_closed",
        "queue_enqueue", "queue_dequeue", "queue_full", "queue_empty",
        "queue_closed",
        "shm_write", "shm_read", "shm_lock_acquire", "shm_lock_release",
        "shm_lock_timeout", "shm_counter_inc", "shm_closed",
        # Channel
        "channel_created",
        # Process
        "process_created", "process_started", "process_stopped",
        # WFG
        "wfg_add_edge", "wfg_remove_edge",
        # Detectors
        "deadlock_detected", "race_detected", "bottleneck_detected",
        # Access
        "access_recorded",
        # Generic
        "info", "warning", "error",
    }

    def __init__(self, log_dir: str = "logs",
                 max_memory_events: int = 5000,
                 on_log: Optional[Callable] = None):
        self._lock = threading.Lock()
        self._buffer: Deque[Dict[str, Any]] = deque(maxlen=max_memory_events)
        self._on_log = on_log

        self._log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._log_path = os.path.join(log_dir, f"ipc_debug_{ts}.jsonl")
        self._file = open(self._log_path, "a", encoding="utf-8")

    # -- public API ----------------------------------------------------------

    def log(self, event: Dict[str, Any]) -> None:
        """Log an event dict.  Must contain at least ``type``."""
        if "time" not in event:
            event["time"] = time.time()
        if "type" not in event:
            event["type"] = "info"
        event["_ts"] = datetime.fromtimestamp(
            event["time"]
        ).strftime("%H:%M:%S.%f")[:-3]

        with self._lock:
            self._buffer.append(event)
            self._file.write(json.dumps(event, default=str) + "\n")
            self._file.flush()

        if self._on_log:
            try:
                self._on_log(event)
            except Exception:
                pass

    def info(self, message: str) -> None:
        self.log({"type": "info", "message": message})

    def warning(self, message: str) -> None:
        self.log({"type": "warning", "message": message})

    def error(self, message: str) -> None:
        self.log({"type": "error", "message": message})

    # -- queries -------------------------------------------------------------

    def get_recent(self, n: int = 50) -> List[Dict[str, Any]]:
        """Return the last *n* events from the ring buffer."""
        with self._lock:
            items = list(self._buffer)
        return items[-n:]

    def get_all(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._buffer)

    def get_by_type(self, event_type: str,
                    n: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            return [e for e in self._buffer
                    if e.get("type") == event_type][-n:]

    def clear(self) -> None:
        with self._lock:
            self._buffer.clear()

    # -- lifecycle -----------------------------------------------------------

    def close(self) -> None:
        with self._lock:
            self._file.close()

    @property
    def log_path(self) -> str:
        return self._log_path

    # -- callback wiring -----------------------------------------------------

    def as_callback(self) -> Callable:
        """Return ``self.log`` — handy for passing to communicators."""
        return self.log
