"""
test_race_condition_detector.py — Unit tests for RaceConditionDetector
"""

import sys
import os
import time
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.analyzers.race_condition_detector import RaceConditionDetector


class TestRaceConditionDetector:

    def test_no_race_read_read(self):
        """Two concurrent reads should not be flagged."""
        rd = RaceConditionDetector(window=1.0)
        rd.record_access(pid=1, resource="shm0", mode="read")
        races = rd.record_access(pid=2, resource="shm0", mode="read")
        assert len(races) == 0

    def test_race_write_write(self):
        """Two concurrent writes without lock → race."""
        rd = RaceConditionDetector(window=1.0)
        rd.record_access(pid=1, resource="shm0", mode="write")
        races = rd.record_access(pid=2, resource="shm0", mode="write")
        assert len(races) == 1
        assert "shm0" in str(races[0])

    def test_race_read_write(self):
        rd = RaceConditionDetector(window=1.0)
        rd.record_access(pid=1, resource="shm0", mode="read")
        races = rd.record_access(pid=2, resource="shm0", mode="write")
        assert len(races) == 1

    def test_no_race_when_locked(self):
        """Both accesses under lock → no race."""
        rd = RaceConditionDetector(window=1.0)
        rd.record_access(pid=1, resource="shm0", mode="write", locked=True)
        races = rd.record_access(pid=2, resource="shm0", mode="write",
                                  locked=True)
        assert len(races) == 0

    def test_window_expiry(self):
        """Accesses outside the window should not be flagged."""
        rd = RaceConditionDetector(window=0.01)
        rd.record_access(pid=1, resource="shm0", mode="write")
        time.sleep(0.05)
        races = rd.record_access(pid=2, resource="shm0", mode="write")
        assert len(races) == 0

    def test_same_pid_no_race(self):
        rd = RaceConditionDetector(window=1.0)
        rd.record_access(pid=1, resource="shm0", mode="write")
        races = rd.record_access(pid=1, resource="shm0", mode="write")
        assert len(races) == 0

    def test_history(self):
        rd = RaceConditionDetector(window=1.0)
        rd.record_access(pid=1, resource="x", mode="write")
        rd.record_access(pid=2, resource="x", mode="write")
        assert len(rd.get_history()) == 1
