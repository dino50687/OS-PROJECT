"""
IPC (Inter-Process Communication) Module
=========================================
This package contains implementations of the three core IPC mechanisms:
  - Pipes (ipc_pipes.py)
  - Message Queues (ipc_message_queue.py)
  - Shared Memory (ipc_shared_memory.py)

Each module wraps Python's multiprocessing primitives and adds instrumentation
for event logging, latency measurement, and debugging hooks used by the
analyzer and visualization layers.
"""

from .ipc_pipes import PipeCommunicator
from .ipc_message_queue import MessageQueueCommunicator
from .ipc_shared_memory import SharedMemoryCommunicator

__all__ = [
    "PipeCommunicator",
    "MessageQueueCommunicator",
    "SharedMemoryCommunicator",
]
