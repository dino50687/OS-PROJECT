"""
test_deadlock_detector.py — Unit tests for DeadlockDetector
"""

import sys
import os
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.analyzers.deadlock_detector import DeadlockDetector


class TestDeadlockDetector:

    def test_no_deadlock(self):
        dd = DeadlockDetector(auto_detect=False)
        dd.add_edge(1, 2, "R1")
        dd.add_edge(2, 3, "R2")
        report = dd.detect()
        assert not report.detected

    def test_simple_cycle(self):
        """Two processes in circular wait → deadlock."""
        dd = DeadlockDetector(auto_detect=False)
        dd.add_edge(1, 2, "R1")
        dd.add_edge(2, 1, "R2")
        report = dd.detect()
        assert report.detected
        assert set(report.cycle) == {1, 2}

    def test_three_way_cycle(self):
        dd = DeadlockDetector(auto_detect=False)
        dd.add_edge(1, 2, "R1")
        dd.add_edge(2, 3, "R2")
        dd.add_edge(3, 1, "R3")
        report = dd.detect()
        assert report.detected
        assert set(report.cycle) == {1, 2, 3}

    def test_remove_edge_breaks_cycle(self):
        dd = DeadlockDetector(auto_detect=False)
        dd.add_edge(1, 2, "R1")
        dd.add_edge(2, 1, "R2")
        dd.remove_edge(2, 1)
        report = dd.detect()
        assert not report.detected

    def test_auto_detect(self):
        """With auto_detect=True, adding the closing edge returns report."""
        reports = []
        dd = DeadlockDetector(auto_detect=True,
                              on_deadlock=lambda r: reports.append(r))
        dd.add_edge(1, 2, "R1")
        dd.add_edge(2, 1, "R2")  # closes the cycle
        assert len(reports) >= 1
        assert reports[-1].detected

    def test_get_graph(self):
        dd = DeadlockDetector(auto_detect=False)
        dd.add_edge(1, 2)
        dd.add_edge(2, 3)
        g = dd.get_graph()
        assert 2 in g[1]
        assert 3 in g[2]

    def test_clear(self):
        dd = DeadlockDetector(auto_detect=False)
        dd.add_edge(1, 2)
        dd.clear()
        assert dd.get_graph() == {}

    def test_large_cycle(self):
        """10-process circular wait."""
        dd = DeadlockDetector(auto_detect=False)
        n = 10
        for i in range(n):
            dd.add_edge(i, (i + 1) % n, f"R{i}")
        report = dd.detect()
        assert report.detected
        assert len(report.cycle) == n
