"""
deadlock_detector.py — Wait-For Graph & Cycle Detection
=========================================================
Implements **deadlock detection** using a directed *Wait-For Graph* (WFG).

Algorithm (pseudocode)
----------------------
1. Maintain a directed graph  G = (V, E)  where:
       V = set of process identifiers
       E = { (Pi, Pj) | Pi is waiting for a resource held by Pj }
2. Periodically (or on every lock-request event) run a DFS-based cycle
   detection on G.
3. If a cycle  C = [P1 → P2 → … → Pk → P1]  is found, report a
   **deadlock** involving those processes.

The debugger tool visualises the WFG on the canvas and highlights cycles
in red.

How the tool illustrates deadlocks
-----------------------------------
* Each process is a **node** on the visualization canvas.
* A directed edge appears when a process requests a lock held by another.
* When a cycle is detected, the involved edges turn **red** and an alert
  is shown in the log panel.
* The user can click "Resolve" to simulate releasing one resource and
  breaking the cycle.
"""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional, Callable, Tuple


@dataclass
class WaitForEdge:
    """Directed edge: *waiter* is blocked waiting for *holder*."""
    waiter: int       # PID
    holder: int       # PID
    resource: str     # human-readable resource name
    timestamp: float = field(default_factory=time.time)


@dataclass
class DeadlockReport:
    """Result of a deadlock scan."""
    detected: bool
    cycle: List[int] = field(default_factory=list)   # PIDs in the cycle
    edges: List[WaitForEdge] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)

    def __str__(self) -> str:
        if not self.detected:
            return "No deadlock detected."
        path = " → ".join(str(p) for p in self.cycle)
        return f"DEADLOCK: {path} → {self.cycle[0]}"


class DeadlockDetector:
    """
    Maintains a live Wait-For Graph and runs cycle detection on demand
    or automatically whenever an edge is added.

    Parameters
    ----------
    auto_detect : bool
        If True, run cycle detection every time ``add_edge`` is called.
    on_deadlock : callable, optional
        Callback ``on_deadlock(DeadlockReport)`` invoked when a cycle is
        found.
    on_event : callable, optional
        Generic event callback used by the event logger.
    """

    def __init__(self, auto_detect: bool = True,
                 on_deadlock: Optional[Callable] = None,
                 on_event: Optional[Callable] = None):
        # adjacency list: waiter → set of holders
        self._adj: Dict[int, Set[int]] = defaultdict(set)
        # edge metadata
        self._edges: Dict[Tuple[int, int], WaitForEdge] = {}
        self.auto_detect = auto_detect
        self._on_deadlock = on_deadlock
        self._on_event = on_event
        self._deadlock_history: List[DeadlockReport] = []

    def _emit(self, event: dict) -> None:
        if self._on_event:
            try:
                self._on_event(event)
            except Exception:
                pass

    # -- Graph mutation ------------------------------------------------------

    def add_edge(self, waiter: int, holder: int,
                 resource: str = "unknown") -> Optional[DeadlockReport]:
        """
        Record that *waiter* is waiting for a resource held by *holder*.
        Returns a ``DeadlockReport`` if a cycle is detected (and
        ``auto_detect`` is enabled), else ``None``.
        """
        edge = WaitForEdge(waiter=waiter, holder=holder, resource=resource)
        self._adj[waiter].add(holder)
        self._edges[(waiter, holder)] = edge
        # Ensure holder node exists
        if holder not in self._adj:
            self._adj[holder] = set()

        self._emit({
            "type": "wfg_add_edge",
            "waiter": waiter,
            "holder": holder,
            "resource": resource,
            "time": time.time(),
        })

        if self.auto_detect:
            return self.detect()
        return None

    def remove_edge(self, waiter: int, holder: int) -> None:
        """Remove an edge (e.g. when the lock is granted or released)."""
        self._adj[waiter].discard(holder)
        self._edges.pop((waiter, holder), None)
        self._emit({
            "type": "wfg_remove_edge",
            "waiter": waiter,
            "holder": holder,
            "time": time.time(),
        })

    def remove_process(self, pid: int) -> None:
        """Remove all edges involving *pid* (process terminated)."""
        self._adj.pop(pid, None)
        for node in list(self._adj):
            self._adj[node].discard(pid)
        for key in list(self._edges):
            if pid in key:
                del self._edges[key]

    def clear(self) -> None:
        """Reset the entire graph."""
        self._adj.clear()
        self._edges.clear()

    # -- Cycle detection (DFS) -----------------------------------------------

    def detect(self) -> DeadlockReport:
        """
        Run DFS-based cycle detection on the Wait-For Graph.

        Returns
        -------
        DeadlockReport
            ``.detected`` is True and ``.cycle`` contains the PID list if a
            cycle (deadlock) is found.
        """
        visited: Set[int] = set()
        rec_stack: Set[int] = set()
        parent: Dict[int, int] = {}
        cycle: List[int] = []

        def dfs(node: int) -> bool:
            visited.add(node)
            rec_stack.add(node)
            for neighbour in self._adj.get(node, set()):
                if neighbour not in visited:
                    parent[neighbour] = node
                    if dfs(neighbour):
                        return True
                elif neighbour in rec_stack:
                    # Found a cycle — reconstruct it
                    cycle.clear()
                    cur = node
                    cycle.append(neighbour)
                    while cur != neighbour:
                        cycle.append(cur)
                        cur = parent.get(cur, neighbour)
                    cycle.reverse()
                    return True
            rec_stack.discard(node)
            return False

        for node in list(self._adj):
            if node not in visited:
                if dfs(node):
                    break

        # Build edges for the cycle
        cycle_edges: List[WaitForEdge] = []
        if cycle:
            for i in range(len(cycle)):
                w = cycle[i]
                h = cycle[(i + 1) % len(cycle)]
                edge = self._edges.get((w, h))
                if edge:
                    cycle_edges.append(edge)

        report = DeadlockReport(
            detected=len(cycle) > 0,
            cycle=cycle,
            edges=cycle_edges,
        )

        if report.detected:
            self._deadlock_history.append(report)
            self._emit({
                "type": "deadlock_detected",
                "cycle": report.cycle,
                "time": time.time(),
            })
            if self._on_deadlock:
                try:
                    self._on_deadlock(report)
                except Exception:
                    pass

        return report

    # -- Queries -------------------------------------------------------------

    def get_graph(self) -> Dict[int, Set[int]]:
        """Return a copy of the adjacency list."""
        return {k: set(v) for k, v in self._adj.items()}

    def get_edges(self) -> List[WaitForEdge]:
        return list(self._edges.values())

    def get_history(self) -> List[DeadlockReport]:
        return list(self._deadlock_history)

    def get_all_processes(self) -> Set[int]:
        pids: Set[int] = set()
        for k, vs in self._adj.items():
            pids.add(k)
            pids.update(vs)
        return pids
