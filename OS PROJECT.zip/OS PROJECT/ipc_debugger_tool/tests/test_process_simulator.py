"""
test_process_simulator.py — Unit tests for ProcessSimulator
"""

import sys
import os
import time
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ipc_debugger_tool.engine.process_simulator import (
    ProcessSimulator, ProcessState,
)


def dummy_worker(stop_event):
    """A simple worker that waits until stopped."""
    while not stop_event.is_set():
        stop_event.wait(0.1)


class TestProcessSimulator:

    def test_create_process(self):
        ps = ProcessSimulator()
        sp = ps.create_process("Worker1")
        assert sp.name == "Worker1"
        assert sp.state == ProcessState.READY
        assert sp.pid >= 1000

    def test_create_multiple(self):
        ps = ProcessSimulator()
        a = ps.create_process("A")
        b = ps.create_process("B")
        assert a.pid != b.pid
        assert len(ps.get_all_processes()) == 2

    def test_start_stop(self):
        ps = ProcessSimulator()
        sp = ps.create_process("W", target=dummy_worker)
        ps.start_process(sp.pid)
        assert sp.state == ProcessState.RUNNING
        time.sleep(0.2)
        ps.stop_process(sp.pid)
        assert sp.state == ProcessState.TERMINATED

    def test_start_all_stop_all(self):
        ps = ProcessSimulator()
        ps.create_process("A", target=dummy_worker)
        ps.create_process("B", target=dummy_worker)
        ps.start_all()
        running = ps.get_running()
        assert len(running) == 2
        ps.stop_all()
        for sp in ps.get_all_processes():
            assert sp.state == ProcessState.TERMINATED

    def test_remove_process(self):
        ps = ProcessSimulator()
        sp = ps.create_process("X")
        ps.remove_process(sp.pid)
        assert ps.get_process(sp.pid) is None

    def test_events(self):
        events = []
        ps = ProcessSimulator(on_event=lambda e: events.append(e))
        sp = ps.create_process("E", target=dummy_worker)
        ps.start_process(sp.pid)
        time.sleep(0.1)
        ps.stop_process(sp.pid)
        types = [e["type"] for e in events]
        assert "process_created" in types
        assert "process_started" in types
        assert "process_stopped" in types
