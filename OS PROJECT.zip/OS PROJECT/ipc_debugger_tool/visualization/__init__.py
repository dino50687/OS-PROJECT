"""
Visualization Package
======================
Provides real-time graphical rendering of IPC activity:
  - VisualizationPanel — Tkinter Canvas widget showing processes & channels
  - AnimationEngine — drives timed animations (data packets, alerts)
"""

from .visualization_panel import VisualizationPanel
from .animation_engine import AnimationEngine

__all__ = [
    "VisualizationPanel",
    "AnimationEngine",
]
