"""
ipc_pipes.py — Pipe-based IPC Communicator
============================================
Wraps ``multiprocessing.Pipe`` with instrumentation for the debugging tool.

A **Pipe** is a unidirectional (or duplex) byte-stream channel between exactly
two endpoints.  It is the simplest IPC mechanism but is limited to two
processes and has a finite kernel buffer that can cause blocking.

Practical applications:
    - Parent ↔ child command / result channels
    - Simple producer → consumer streaming

Benefits:
    - Extremely fast (kernel buffer, no serialization overhead for small msgs)
    - Easy API (send / recv)

Constraints:
    - Two endpoints only (not multicast)
    - Blocking when the buffer is full (potential for deadlock)
    - No built-in message boundaries in raw OS pipes (Python Pipe *does*
      pickle objects, so boundaries are preserved at the Python level)

Common coding errors:
    - Forgetting to close unused ends → resource leak / hang
    - Both ends calling recv simultaneously on a half-duplex pipe
    - Sending unpicklable objects
"""

from __future__ import annotations

import time
import multiprocessing
from multiprocessing.connection import Connection
from dataclasses import dataclass, field
from typing import Any, Optional, Callable

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class PipeMessage:
    """A single message transmitted through a pipe."""
    sender_pid: int
    receiver_pid: int
    payload: Any
    timestamp: float = field(default_factory=time.time)
    latency: float = 0.0          # filled in on receive


@dataclass
class PipeStats:
    """Cumulative statistics for one pipe channel."""
    messages_sent: int = 0
    messages_received: int = 0
    bytes_sent: int = 0
    total_latency: float = 0.0
    max_latency: float = 0.0
    blocked_count: int = 0        # how many times send/recv blocked

    @property
    def avg_latency(self) -> float:
        if self.messages_received == 0:
            return 0.0
        return self.total_latency / self.messages_received


# ---------------------------------------------------------------------------
# Communicator
# ---------------------------------------------------------------------------

class PipeCommunicator:
    """
    Instrumented wrapper around ``multiprocessing.Pipe``.

    Parameters
    ----------
    duplex : bool
        If *True* (default), both ends can send and receive.
    on_event : callable, optional
        ``on_event(event_dict)`` is called for every send / recv / block.
    """

    def __init__(self, duplex: bool = True,
                 on_event: Optional[Callable] = None):
        self.conn_a: Connection
        self.conn_b: Connection
        self.conn_a, self.conn_b = multiprocessing.Pipe(duplex=duplex)
        self.duplex = duplex
        self.stats = PipeStats()
        self._on_event = on_event
        self._closed = False

    # -- helpers -------------------------------------------------------------

    def _emit(self, event: dict) -> None:
        if self._on_event:
            try:
                self._on_event(event)
            except Exception:
                pass  # never let callback crash the IPC layer

    # -- public API ----------------------------------------------------------

    def send(self, conn: Connection, payload: Any,
             sender_pid: int = 0, receiver_pid: int = 0,
             timeout: Optional[float] = None) -> PipeMessage:
        """
        Send *payload* through *conn* (should be ``self.conn_a`` or
        ``self.conn_b``).

        Returns the ``PipeMessage`` that was sent (with timestamp).
        """
        msg = PipeMessage(
            sender_pid=sender_pid,
            receiver_pid=receiver_pid,
            payload=payload,
        )
        t0 = time.time()
        blocked = False

        # Detect potential blocking: poll before send
        # (Connection.send blocks when kernel buffer is full)
        if timeout is not None:
            if not conn.writable:
                blocked = True
                self.stats.blocked_count += 1
                self._emit({
                    "type": "pipe_blocked",
                    "direction": "send",
                    "sender": sender_pid,
                    "receiver": receiver_pid,
                    "time": t0,
                })

        conn.send(payload)
        elapsed = time.time() - t0

        import sys
        data_size = sys.getsizeof(payload)
        self.stats.messages_sent += 1
        self.stats.bytes_sent += data_size

        self._emit({
            "type": "pipe_send",
            "sender": sender_pid,
            "receiver": receiver_pid,
            "size": data_size,
            "time": msg.timestamp,
            "blocked": blocked,
            "send_duration": elapsed,
        })
        return msg

    def recv(self, conn: Connection,
             sender_pid: int = 0, receiver_pid: int = 0,
             timeout: Optional[float] = None) -> Any:
        """
        Receive from *conn*.  Returns the payload object.
        """
        t0 = time.time()
        blocked = False

        if timeout is not None:
            ready = conn.poll(timeout)
            if not ready:
                blocked = True
                self.stats.blocked_count += 1
                self._emit({
                    "type": "pipe_blocked",
                    "direction": "recv",
                    "sender": sender_pid,
                    "receiver": receiver_pid,
                    "time": t0,
                })
                return None  # timed out

        payload = conn.recv()
        latency = time.time() - t0

        self.stats.messages_received += 1
        self.stats.total_latency += latency
        self.stats.max_latency = max(self.stats.max_latency, latency)

        self._emit({
            "type": "pipe_recv",
            "sender": sender_pid,
            "receiver": receiver_pid,
            "latency": latency,
            "time": time.time(),
        })
        return payload

    def close(self) -> None:
        """Close both ends of the pipe."""
        if not self._closed:
            self.conn_a.close()
            self.conn_b.close()
            self._closed = True
            self._emit({"type": "pipe_closed", "time": time.time()})

    def get_stats(self) -> dict:
        """Return a plain dict snapshot of current statistics."""
        return {
            "messages_sent": self.stats.messages_sent,
            "messages_received": self.stats.messages_received,
            "bytes_sent": self.stats.bytes_sent,
            "avg_latency": self.stats.avg_latency,
            "max_latency": self.stats.max_latency,
            "blocked_count": self.stats.blocked_count,
        }
