"""
ipc_message_queue.py — Message-Queue-based IPC Communicator
=============================================================
Wraps ``multiprocessing.Queue`` with instrumentation.

A **Message Queue** is a kernel-managed FIFO that allows multiple producers
and consumers.  Messages are discrete, ordered, and buffered.

Practical applications:
    - Task / work-item distribution (thread pools, worker pipelines)
    - Logging pipelines
    - Event buses inside a single machine

Benefits:
    - Multiple producers and consumers (fan-out / fan-in)
    - Kernel-buffered → decouples speeds of sender and receiver
    - Built-in blocking semantics (``put`` / ``get`` with timeout)

Constraints:
    - Slower than pipes for two-party communication (extra locking overhead)
    - Maximum queue size can lead to blocking producers
    - Messages are copied (pickled) — large payloads are expensive

Common coding errors:
    - Queue full → producer blocks silently
    - Forgetting ``queue.close()`` / ``queue.join_thread()`` → zombie feeder
    - Deadlock when a child process fills the queue and the parent joins
      before draining it
"""

from __future__ import annotations

import sys
import time
import multiprocessing
from dataclasses import dataclass, field
from typing import Any, Optional, Callable


@dataclass
class QueueMessage:
    sender_pid: int
    payload: Any
    timestamp: float = field(default_factory=time.time)
    priority: int = 0  # lower = higher priority (for future use)


@dataclass
class QueueStats:
    messages_enqueued: int = 0
    messages_dequeued: int = 0
    bytes_enqueued: int = 0
    total_latency: float = 0.0
    max_latency: float = 0.0
    full_events: int = 0   # producer blocked because queue was full
    empty_events: int = 0  # consumer saw empty queue
    peak_size: int = 0

    @property
    def avg_latency(self) -> float:
        if self.messages_dequeued == 0:
            return 0.0
        return self.total_latency / self.messages_dequeued


class MessageQueueCommunicator:
    """
    Instrumented wrapper around ``multiprocessing.Queue``.

    Parameters
    ----------
    maxsize : int
        Maximum number of items in the queue (0 = unlimited).
    on_event : callable, optional
        Callback fired on every enqueue / dequeue / block event.
    """

    def __init__(self, maxsize: int = 0,
                 on_event: Optional[Callable] = None):
        self.queue: multiprocessing.Queue = multiprocessing.Queue(maxsize=maxsize)
        self.maxsize = maxsize
        self.stats = QueueStats()
        self._on_event = on_event

    def _emit(self, event: dict) -> None:
        if self._on_event:
            try:
                self._on_event(event)
            except Exception:
                pass

    # -- public API ----------------------------------------------------------

    def enqueue(self, payload: Any, sender_pid: int = 0,
                timeout: Optional[float] = None) -> QueueMessage:
        """Put a message onto the queue."""
        msg = QueueMessage(sender_pid=sender_pid, payload=payload)
        t0 = time.time()
        blocked = False

        try:
            self.queue.put(payload, block=True, timeout=timeout)
        except Exception:
            # queue.Full
            blocked = True
            self.stats.full_events += 1
            self._emit({
                "type": "queue_full",
                "sender": sender_pid,
                "time": t0,
            })
            raise

        elapsed = time.time() - t0
        data_size = sys.getsizeof(payload)
        self.stats.messages_enqueued += 1
        self.stats.bytes_enqueued += data_size

        try:
            current_size = self.queue.qsize()
        except NotImplementedError:
            current_size = self.stats.messages_enqueued - self.stats.messages_dequeued
        self.stats.peak_size = max(self.stats.peak_size, current_size)

        self._emit({
            "type": "queue_enqueue",
            "sender": sender_pid,
            "size": data_size,
            "queue_depth": current_size,
            "time": msg.timestamp,
            "blocked": blocked,
            "put_duration": elapsed,
        })
        return msg

    def dequeue(self, receiver_pid: int = 0,
                timeout: Optional[float] = None) -> Any:
        """Get a message from the queue.  Returns ``None`` on timeout."""
        t0 = time.time()
        try:
            payload = self.queue.get(block=True, timeout=timeout)
        except Exception:
            # queue.Empty
            self.stats.empty_events += 1
            self._emit({
                "type": "queue_empty",
                "receiver": receiver_pid,
                "time": t0,
            })
            return None

        latency = time.time() - t0
        self.stats.messages_dequeued += 1
        self.stats.total_latency += latency
        self.stats.max_latency = max(self.stats.max_latency, latency)

        self._emit({
            "type": "queue_dequeue",
            "receiver": receiver_pid,
            "latency": latency,
            "time": time.time(),
        })
        return payload

    def current_size(self) -> int:
        try:
            return self.queue.qsize()
        except NotImplementedError:
            return max(0, self.stats.messages_enqueued - self.stats.messages_dequeued)

    def close(self) -> None:
        self.queue.close()
        self.queue.join_thread()
        self._emit({"type": "queue_closed", "time": time.time()})

    def get_stats(self) -> dict:
        return {
            "messages_enqueued": self.stats.messages_enqueued,
            "messages_dequeued": self.stats.messages_dequeued,
            "bytes_enqueued": self.stats.bytes_enqueued,
            "avg_latency": self.stats.avg_latency,
            "max_latency": self.stats.max_latency,
            "full_events": self.stats.full_events,
            "empty_events": self.stats.empty_events,
            "peak_size": self.stats.peak_size,
            "current_size": self.current_size(),
        }
