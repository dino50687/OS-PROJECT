"""
race_condition_detector.py — Concurrent-Access Pattern Analyzer
=================================================================
Detects potential **race conditions** by tracking read/write access
patterns to shared resources and flagging unsynchronized concurrent
accesses.

A *race condition* occurs when:
    1. Two or more processes access the same shared resource, AND
    2. At least one of the accesses is a **write**, AND
    3. The accesses are **not protected** by a mutual-exclusion mechanism.

Detection heuristic
--------------------
* Maintain an access log:  ``(pid, resource, mode, time, locked?)``
* Define a *concurrency window* Δt (e.g. 50 ms).
* Two accesses are *concurrent* if their timestamps differ by less than Δt
  and they come from **different** processes.
* Flag a race if concurrent accesses satisfy conditions (1)–(3) above.

This is a *best-effort* dynamic detector — it reports *observed* races,
not all possible ones (similar in spirit to ThreadSanitizer / Helgrind).
"""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Set


@dataclass
class AccessRecord:
    pid: int
    resource: str
    mode: str          # "read" or "write"
    timestamp: float
    locked: bool       # True if the access was inside a lock region


@dataclass
class RaceReport:
    resource: str
    access_a: AccessRecord
    access_b: AccessRecord
    timestamp: float = field(default_factory=time.time)

    def __str__(self) -> str:
        return (
            f"RACE on '{self.resource}': "
            f"PID {self.access_a.pid} ({self.access_a.mode}) vs "
            f"PID {self.access_b.pid} ({self.access_b.mode})"
        )


class RaceConditionDetector:
    """
    Tracks shared-resource accesses and detects unsynchronized concurrent
    read-write or write-write patterns.

    Parameters
    ----------
    window : float
        Concurrency window in seconds (default 0.05 = 50 ms).
    on_race : callable, optional
        ``on_race(RaceReport)`` called when a race is found.
    on_event : callable, optional
        Generic event callback.
    """

    def __init__(self, window: float = 0.05,
                 on_race: Optional[Callable] = None,
                 on_event: Optional[Callable] = None):
        self.window = window
        self._on_race = on_race
        self._on_event = on_event
        # resource_name → list of recent AccessRecords
        self._recent: Dict[str, List[AccessRecord]] = defaultdict(list)
        self._race_history: List[RaceReport] = []

    def _emit(self, event: dict) -> None:
        if self._on_event:
            try:
                self._on_event(event)
            except Exception:
                pass

    def record_access(self, pid: int, resource: str,
                      mode: str = "read",
                      locked: bool = False) -> List[RaceReport]:
        """
        Record an access and return any races detected against recent
        accesses.
        """
        now = time.time()
        rec = AccessRecord(pid=pid, resource=resource, mode=mode,
                           timestamp=now, locked=locked)

        # Prune old entries outside the window
        recent = self._recent[resource]
        recent[:] = [r for r in recent if now - r.timestamp < self.window]

        races: List[RaceReport] = []
        for other in recent:
            if other.pid == pid:
                continue  # same process — not a race
            if other.locked and locked:
                continue  # both under lock — protected
            if mode == "read" and other.mode == "read":
                continue  # read-read — safe
            # This is a potential race (read-write or write-write)
            report = RaceReport(resource=resource,
                                access_a=other, access_b=rec)
            races.append(report)
            self._race_history.append(report)
            self._emit({
                "type": "race_detected",
                "resource": resource,
                "pid_a": other.pid,
                "mode_a": other.mode,
                "pid_b": pid,
                "mode_b": mode,
                "time": now,
            })
            if self._on_race:
                try:
                    self._on_race(report)
                except Exception:
                    pass

        recent.append(rec)
        self._emit({
            "type": "access_recorded",
            "pid": pid,
            "resource": resource,
            "mode": mode,
            "locked": locked,
            "time": now,
        })
        return races

    def get_history(self) -> List[RaceReport]:
        return list(self._race_history)

    def clear(self) -> None:
        self._recent.clear()
        self._race_history.clear()

    def get_monitored_resources(self) -> Set[str]:
        return set(self._recent.keys())
