# Top-level __init__.py for the ipc_debugger_tool package
"""
IPC Debugger Tool
==================
A comprehensive debugging tool for Inter-Process Communication mechanisms
(Pipes, Message Queues, Shared Memory) with deadlock, race-condition, and
bottleneck detection, plus real-time GUI visualization.
"""

__version__ = "1.0.0"
